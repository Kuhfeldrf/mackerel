"""Stress-test tuned one-piece head-down candidates against the ~0.30 m/s target."""
import json, sys
from multiprocessing import Pool
import numpy as np
import fish3, sim3
import tune_onepiece as T
from robust_onepiece import samples

K = 12


TRIM = None          # grams in sea water to trim each build to (None = no trim)


def one(a):
    p, s = a
    dlead = s["dlead"]
    if TRIM is not None:            # builder trims the lead after painting until the in-water weight hits TRIM
        for _ in range(2):
            b0 = T.body_for(p, coat=s["coat"], rho=s["rho"], dlead=dlead, dx=s["dx"])
            dlead += (TRIM - b0.meta["net_g"]) / (1 - 1.025 / 11.34)
    body = T.body_for(p, coef=s["coef"], coat=s["coat"], rho=s["rho"], dlead=dlead, dx=s["dx"])
    R0 = sim3.rot(s["toss_axis"], s["toss_deg"]) @ fish3.R_START
    try:
        fr = fish3.run(body, R0=R0, v0=np.array([0.7, -0.25, 0.15]) * s["v_scale"])
    except RuntimeError:
        return None
    m = fish3.metrics(fr, body)
    ok, ch = T.target(m)
    return dict(m=m, ok=ok, checks=ch)


if __name__ == "__main__":
    cands = json.loads(sys.argv[1])
    if len(sys.argv) > 3:
        TRIM = float(sys.argv[3])
    S = samples()
    with Pool(2) as pool:
        res = pool.map(one, [(c, s) for c in cands for s in S])
    out = []
    for i, p in enumerate(cands):
        rs = [r for r in res[i * K:(i + 1) * K] if r]
        q = lambda f: np.percentile([f(r["m"]) for r in rs], [10, 50, 90]).round(2).tolist()
        out.append(dict(p=p, success=f"{sum(r['ok'] for r in rs)}/{len(rs)}", each={c: sum(r["checks"][c] for r in rs) for c in rs[0]["checks"]},
                        sink=q(lambda m: m["sink"]), head_down=q(lambda m: m["head_down"]),
                        rock=q(lambda m: 1.4 * max(m["roll_osc"], m["head_down_osc"])),
                        turn_s=q(lambda m: 360 / max(abs(m["yaw_rate"]), 1)), net_g=q(lambda m: m["net_g"])))
        print(json.dumps(out[-1]), flush=True)
    json.dump(out, open(sys.argv[2], "w"), indent=1)
    print("ROBUST_DONE")
