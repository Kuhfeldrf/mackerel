"""Viewer data for the one-piece PLA prints -> out/web/pla_data.js (overrides FISH.wounded/scurve/curled/straight)."""
import base64, json
import numpy as np
import mackerel_geom as G
import wounded as W
import fish3
import sim_pla_all as SP
from build_onepiece import LINE_X

b64 = lambda a: base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()
FL = G.FL


def cylinder(axis, centre, r, length, n=28):
    ang = np.linspace(0, 2 * np.pi, n, endpoint=False)
    ring = np.c_[r * np.cos(ang), r * np.sin(ang)]
    V, F = [], []
    for h in (-length / 2, length / 2):
        for (u, v) in ring:
            p = {"x": (h, u, v), "y": (u, h, v), "z": (u, v, h)}[axis]
            V.append(p)
    V += [{"x": (-length / 2, 0, 0), "y": (0, -length / 2, 0), "z": (0, 0, -length / 2)}[axis],
          {"x": (length / 2, 0, 0), "y": (0, length / 2, 0), "z": (0, 0, length / 2)}[axis]]
    c0, c1 = 2 * n, 2 * n + 1
    for i in range(n):
        j = (i + 1) % n
        F += [(i, j, n + j), (i, n + j, n + i), (c0, j, i), (c1, n + i, n + j)]
    V = np.asarray(V, float) + np.asarray(centre, float)
    return V.astype(np.float32), np.asarray(F, np.uint16)


def part(name, kind, V, F, centre, cc=0.0, label=None):
    return dict(name=name, kind=kind, cc=round(cc, 2), centre=[round(float(c), 2) for c in centre], v=b64(V), f=b64(F), label=label or name)


def line_parts():
    c, yc, w, per = fish3.section(LINE_X)
    out = []
    V, F = cylinder("y", (LINE_X, yc, 0), 1.1, c + 0.4)
    out.append(part("LINE_HOLE", "hole", V, F, (LINE_X, yc, 0), label="Line tie hole"))
    V, F = cylinder("y", (LINE_X, yc + 14, 0), 0.35, c + 28)
    out.append(part("LINE", "line", V, F, (LINE_X, yc + c / 2 + 12, 0), label="Line"))
    return out


def info(name):
    return json.load(open(f"out/onepiece/{name}_onepiece_info.json"))


data = {}
# --- head-down one-piece
import export_wounded_web as EW          # reuse its coarse cavity mesher (module runs its own export for 'wounded' - harmless)
import cavities as CV
hd = info("headdown")
zeye = float(G.body_z(np.array([G.EYE_X]), np.array([G.EYE_Y]))[0][0])
parts = []
for c in CV.cavities():
    if c["kind"] == "air":
        V, F = EW.coarse_cavity(c["name"], c["x0"], c["x1"], c["band"])
        parts.append(part(c["name"], "air", V, F, c["centre"], c["cc"], label="Sealed air"))
V, F = cylinder("z", (G.EYE_X, G.EYE_Y, 0), hd["bore_mm"] / 2 - 0.1, 2 * zeye - 2.0)
parts.append(part("LEAD", "lead", V, F, (G.EYE_X, G.EYE_Y, 0), np.pi * (hd["bore_mm"] / 2) ** 2 * 2 * zeye / 1000, label="Lead"))
parts += line_parts()
bend = W.BendSegments([(SP.HEAD["bend"], 0.30, 0.66, 0.10), (SP.HEAD["kick"], 0.83, 0.94, 0.04)])
bb = hd["bbox_mm"]
data["wounded"] = dict(theta=b64(bend.th.astype(np.float32)), charges=SP.LEAD, defaultCharge=SP.LEAD_DEFAULT, chambers=parts,
                       specs=[["File", hd["file"]], ["Print size", f"{bb[0]:.0f} × {bb[1]:.0f} × {bb[2]:.0f} mm, upright"],
                              ["Shape", f"{SP.HEAD['bend']}° body bend, {SP.HEAD['kick']}° tail kick"],
                              ["Inside", "2 sealed air voids (~22 cc) printed in"],
                              ["Lead", f"{hd['bore_mm']:.0f} mm bore between the eyes, up to ~{hd['lead_g_fill']:.0f} g"],
                              ["PLA", f"~{hd['pla_g_100pct']:.0f} g at 100% infill (~${hd['cost_usd']:.0f})"],
                              ["Tuning", "headdown_kick0 / kick20 files"]])
# --- solid PLA designs
for d, fname, label in (("scurve", "scurve", "S-curve"), ("curled", "ucurl", "U-curl"), ("straight", "straight", "Straight")):
    inf = info(fname)
    bb = inf["bbox_mm"]
    entry = dict(charges=[], defaultCharge=0, chambers=line_parts(),
                 specs=[["File", inf["file"]], ["Print size", f"{bb[0]:.0f} × {bb[1]:.0f} × {bb[2]:.0f} mm, upright"],
                        ["Inside", "solid PLA, no ballast, no air"],
                        ["PLA", f"~{inf['pla_g_100pct']:.0f} g at 100% infill (~${inf['cost_usd']:.0f})"]])
    if d == "scurve":
        entry["theta"] = b64(W.BendSegments(W.S_SEGMENTS).th.astype(np.float32))
    if d == "curled":
        entry["curl_deg"] = 230.0
    data[d] = entry
js = "Object.assign(window.FISH," + json.dumps(data, separators=(",", ":")) + ");\n"
open("out/web/pla_data.js", "w").write(js)
print("pla_data.js KB", len(js) // 1024)
