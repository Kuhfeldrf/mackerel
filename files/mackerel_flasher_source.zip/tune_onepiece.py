"""
Tune the one-piece head-down print for a balanced ~0.30 m/s sink:
lead slug (g), body bend, tail kick and sealed-air length (x end of the voids, fraction of FL).
"""
import json, sys
from functools import lru_cache
from multiprocessing import Pool
import numpy as np
import trimesh
import fish3, cavities as CV, wounded as W, mackerel_geom as G

COAT, RHO = 6.0, 1.22


@lru_cache(maxsize=None)
def air(x1):
    out = []
    for name, x0, _, band, kind in CV.SPECS:
        if kind != "air":
            continue
        V, F = CV.cavity_mesh(name, x0, x1, band)
        tm = trimesh.Trimesh(V, F, process=False)
        out.append(dict(name=name, centre=tm.center_mass.round(2).tolist(), cc=round(tm.volume / 1000, 3), kind="air"))
    return out


def body_for(p, coef=None, coat=COAT, rho=RHO, dlead=0.0, dx=0.0):
    bend = W.BendSegments([(p["bend"], 0.30, 0.66, 0.10), (p["kick"], 0.83, 0.94, 0.04)])
    g = p["lead"] + dlead
    extra = [(g, (G.EYE_X + dx, G.EYE_Y, 0.0), g / 11.34)]
    return fish3.make_body("wounded", {}, coef=coef, coat_g=coat, extra=extra, bend=bend, chambers=air(p["air"]), rho_p=rho)


def target(m):
    rock = 1.4 * max(m["roll_osc"], m["head_down_osc"])
    turn = abs(m["yaw_rate"])
    checks = dict(sink_030=0.26 <= m["sink"] <= 0.34, head_first=35 <= m["head_down"] <= 72,
                  light_flutter=4 <= rock <= 22, slow_spiral=24 <= turn <= 180 and m["sway_m"] <= 0.5)
    return all(checks.values()), checks


def job(p):
    b = body_for(p)
    fr = fish3.run(b)
    m = fish3.metrics(fr, b)
    ok, ch = target(m)
    return p, m, ok, ch


if __name__ == "__main__":
    J = [dict(lead=l, bend=b, kick=k, air=a) for l in (10, 12) for b in (35, 45) for k in (0, 10, 20) for a in (0.62, 0.70)]
    with Pool(2) as pool:
        for p, m, ok, ch in pool.imap_unordered(job, J):
            print(json.dumps(dict(p=p, ok=ok, fail=[k for k, v in ch.items() if not v],
                                  m={k: m[k] for k in ("net_g", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")})), flush=True)
    print("TUNE_DONE")
