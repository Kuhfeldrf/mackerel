"""
All-PLA version: solid single-material halves, no ballast, no air pockets.
Same outside shape (and engraved back pattern) as the chosen design; keeps the
line channel and alignment pins. Outputs each half and a combined print plate,
each under 5 MB (OSU Valley Library upload limit).
usage: python3 build_pla.py NAME BEND_DEG KICK_DEG      (or NAME scurve)
"""
import json, os, sys
import numpy as np
import trimesh
import manifold3d as m3d
import mackerel_geom as G
import build_curled as BC
import wounded as W

OUT = "out/pla"
FL = G.FL
os.makedirs(OUT, exist_ok=True)


def build(name, bend):
    BC.MAX_AREA = 0.36
    poly, V2, F, z, t = BC.skin()
    body, _, _ = BC.full_body(V2, F, z)
    cuts = []
    wr = 2.0 / 2                      # 2.0 mm line channel: thread mono/braid through, knot at the tail fork (no steel wire)
    cuts.append(m3d.Manifold.cylinder(FL + 4, wr, wr, 16).rotate([0, 90, 0]).translate([-2, 0, 0]))
    pins = []
    for px in (0.12 * FL, 0.30 * FL, 0.50 * FL, 0.70 * FL):
        Wd = BC.zbody_at(px, -4.0)[0]
        pz = round(0.5 * Wd, 1)
        if Wd - pz - (G.PIN_D + 0.2) / 2 < 1.0:
            continue
        r = (G.PIN_D + 0.2) / 2
        for sgn in (1, -1):
            cuts.append(m3d.Manifold.cylinder(8.0, r, r, 16).rotate([90, 0, 0]).translate([px, 4.0, sgn * pz]))
        pins.append(dict(x=round(px, 1), z=pz))
    body = body - m3d.Manifold.batch_boolean(cuts, m3d.OpType.Add)
    if bend is not None:
        body = body.refine_to_length(2.0)
        body = body.warp_batch(lambda P: bend(P))
    back, belly = body.split_by_plane([0, 1, 0], 0.0)

    def tm(M):
        mm = M.to_mesh()
        return trimesh.Trimesh(np.asarray(mm.vert_properties)[:, :3], np.asarray(mm.tri_verts), process=True)

    D, Vt = tm(back), tm(belly)
    rot = trimesh.transformations.rotation_matrix
    D.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    Vt.apply_transform(rot(-np.pi / 2, [1, 0, 0]))
    for m in (D, Vt):
        m.apply_translation(-m.bounds[0])
    # combined plate: belly half placed beside the back half
    Vt2 = Vt.copy(); Vt2.apply_translation([0, D.extents[1] + 8, 0])
    plate = trimesh.util.concatenate([D, Vt2])
    files = {}
    for tag, m in (("BACK_half", D), ("BELLY_half", Vt), ("PLATE_both_halves", plate)):
        fn = f"{OUT}/{name}_PLA_{tag}.stl"
        m.export(fn)
        files[tag] = dict(file=os.path.basename(fn), MB=round(os.path.getsize(fn) / 1e6, 2), bbox=m.extents.round(1).tolist(),
                          watertight=bool(m.is_watertight) if tag != "PLATE_both_halves" else None)
    vol = (D.volume + Vt.volume) / 1000
    info = dict(name=name, pins=pins, files=files, volume_cc=round(vol, 2),
                mass_g_100pct=round(vol * 1.24, 1), cost_usd_at_16c_per_g=round(vol * 1.24 * 0.16, 2))
    json.dump(info, open(f"{OUT}/{name}_PLA_info.json", "w"), indent=1)
    return info


if __name__ == "__main__":
    name = sys.argv[1]
    if sys.argv[2] == "scurve":
        bend = W.BendSegments(W.S_SEGMENTS)
    else:
        b, k = float(sys.argv[2]), float(sys.argv[3])
        bend = W.BendSegments([(b, 0.30, 0.66, 0.10), (k, 0.83, 0.94, 0.04)]) if (b or k) else None
    print(json.dumps(build(name, bend), indent=1))
