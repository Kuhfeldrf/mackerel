"""Inject mesh/texture data and sink trajectories into the viewer template."""
import json
t = open("web_template.html").read()
fish = open("out/web/fish_data.js").read()
sink = json.load(open("out/web/sink_data.json"))
wd = open("out/web/pla_data.js").read()
sd = ""
t = t.replace("/*FISH_DATA*/", fish).replace("/*WOUNDED_DATA*/", wd).replace("/*SCURVE_DATA*/", sd).replace("/*SINK_DATA*/", "window.SINK=" + json.dumps(sink, separators=(",", ":")) + ";")
open("out/web/chub_mackerel_flasher.html", "w").write(t)
print("page KB", len(t) // 1024)
