"""Quick shaded renders of an STL (orthographic, painter's algorithm)."""
import sys
import numpy as np
import trimesh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection


def render(mesh, ax, elev, azim, color=(0.72, 0.75, 0.78)):
    m = mesh
    V = m.vertices - m.bounds.mean(axis=0)
    e, a = np.radians(elev), np.radians(azim)
    # camera basis
    d = np.array([np.cos(e) * np.cos(a), np.cos(e) * np.sin(a), np.sin(e)])  # toward camera
    right = np.cross([0, 0, 1], d); right /= np.linalg.norm(right)
    up = np.cross(d, right)
    P = np.c_[V @ right, V @ up]
    depth = V @ d
    F = m.faces
    n = m.face_normals
    vis = n @ d > 0
    F, n = F[vis], n[vis]
    order = np.argsort(depth[F].mean(axis=1))
    F, n = F[order], n[order]
    L = np.array([0.3, 0.4, 0.85]); L = L / np.linalg.norm(L)
    Lc = L[0] * right + L[1] * up + L[2] * d
    shade = 0.25 + 0.75 * np.clip(n @ Lc, 0, 1)
    cols = np.clip(np.outer(shade, color), 0, 1)
    pc = PolyCollection(P[F], facecolors=cols, edgecolors=cols, linewidths=0.05)
    ax.add_collection(pc)
    ax.set_xlim(P[:, 0].min() - 3, P[:, 0].max() + 3)
    ax.set_ylim(P[:, 1].min() - 3, P[:, 1].max() + 3)
    ax.set_aspect("equal")
    ax.axis("off")


if __name__ == "__main__":
    mesh = trimesh.load(sys.argv[1])
    out = sys.argv[2]
    views = [(35, -70, "3/4 view (top surface)"), (-50, -60, "mating face (pockets, wire channel, pin holes)"),
             (8, -88, "low side view")]
    fig, axs = plt.subplots(len(views), 1, figsize=(12, 11), dpi=130)
    for ax, (el, az, title) in zip(axs, views):
        render(mesh, ax, el, az)
        ax.set_title(title, fontsize=10)
    plt.tight_layout()
    plt.savefig(out, facecolor="white")
