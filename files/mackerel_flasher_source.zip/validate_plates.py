"""
Validate sim3's strip model against Andersen, Pesavento & Wang (JFM 2005), Table 1:
aluminium plates (19 cm span) falling in water.
"""
import json, sys
import numpy as np
import sim3

sim3.RHO_W = 1000.0
RHO_S = 2700.0
L = 0.19
# beta, h (m), measured: v_x (cm/s), v_y (cm/s), omega (rad/s), regime, APW fitted CR, CD0
PLATES = [
    (1 / 5, 0.00162, 14.2, -8.1, 25.5, "tumbling", 1.4, 0.28),
    (1 / 6, 0.00162, 15.2, -16.2, 16.1, "chaotic", 1.2, 0.15),
    (1 / 8, 0.00081, 15.9, -11.5, 14.5, "tumbling", 1.0, 0.13),
    (1 / 14, 0.00081, 19.8, -9.0, 6.8, "fluttering", 1.1, 0.08),
]


def plate_body(beta, h, coef):
    l = h / beta
    m = RHO_S * l * h * L
    I = np.diag([m * (L ** 2 + h ** 2) / 12, m * (L ** 2 + l ** 2) / 12, m * (l ** 2 + h ** 2) / 12])
    strips = dict(r=[[0, 0, 0]], t=[[0, 0, 1]], a=[[1, 0, 0]], b=[[0, 1, 0]], ds=[L], c=[l], w=[h], per=[2 * (l + h)])
    return sim3.Body(m, I, [0, 0, 0], l * h * L, strips, coef=coef), l


def run_plate(beta, h, coef, tilt_deg=8.0, t_max=8.0):
    body, l = plate_body(beta, h, coef)
    q0 = sim3.mat2q(sim3.rot([0, 0, 1], tilt_deg))
    s0 = np.r_[[0, 0, 0], q0, [0, 0, 0], [0, 0, 0]]
    fr = sim3.integrate(body, s0, 0.0004, t_max, 400)
    tt = np.arange(len(fr)) / 400
    late = tt > t_max * 0.4
    R = [sim3.qrot(q) for q in fr[late, 3:7]]
    # world velocities
    vw = np.array([Rk @ fr[i, 7:10] for Rk, i in zip(R, np.nonzero(late)[0])])
    theta = np.unwrap(np.array([np.arctan2(Rk[1, 0], Rk[0, 0]) for Rk in R]))
    om = np.abs(fr[late, 12])
    total_turn = abs(theta[-1] - theta[0])
    regime = "tumbling" if total_turn > 4 * np.pi else ("fluttering" if np.ptp(theta) > np.radians(20) else "steady")
    return dict(vx=round(float(np.mean(np.abs(vw[:, 0]))) * 100, 1), vy=round(float(np.mean(vw[:, 1])) * 100, 1),
                omega=round(float(np.mean(om)), 1), regime=regime)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "apw"
    out = []
    for beta, h, vx, vy, om, reg, CR, CD0 in PLATES:
        coef = dict(CT=1.0, CR=CR, CD0=CD0, CD90=2.0, Ca=1.0, Crot=float(sys.argv[2]) if len(sys.argv) > 2 else 1.0)
        if mode == "fish":          # one coefficient set for thick fish sections
            coef = dict(sim3.COEF)
        r = run_plate(beta, h, coef)
        out.append(dict(beta=f"1/{round(1 / beta)}", measured=dict(vx=vx, vy=vy, omega=om, regime=reg), model=r))
        print(out[-1], flush=True)
    json.dump(out, open(f"out/validate_plates_{mode}_{sys.argv[2] if len(sys.argv) > 2 else 1}.json", "w"), indent=1)
