"""Assemble the 1:1 decal sheet + build sheet PDF."""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image
import mackerel_geom as G

OUT = "out"
info = json.load(open(f"{OUT}/model_info.json"))
poly = G.outline()

# ------------------------------------------------------------- ballast maths
RHO_SW, RHO_PETG, RHO_EPOXY = 1.025, 1.27, 1.15
V_solid = 2 * info["half_volume_cc"]
ch = {c["name"]: c["volume_both_halves_cc"] for c in info["chambers"]}
V_ch = sum(ch.values())
V_disp = V_solid + V_ch
m_print = RHO_PETG * V_solid * 0.97
m_coat = 6.0
A_side = info["side_area_mm2"] * 1e-6


def scenario(label, fill):
    """fill: dict chamber -> (density_of_fill, packing); remaining space = epoxy."""
    m_ball = 0.0
    for name, vol in ch.items():
        if name in fill:
            dens, pack = fill[name]
            m_ball += vol * (dens * pack + RHO_EPOXY * (1 - pack))
        else:
            m_ball += vol * RHO_EPOXY
    total = m_print + m_coat + m_ball
    net = total - RHO_SW * V_disp
    v = np.sqrt(max(net, 0) / 1000 * 9.81 * 2 / (1025 * 1.2 * A_side))
    return [label, f"{total:.0f} g", f"{net:.0f} g", f"{v:.2f} m/s", f"{10 / v:.0f} s" if v > 0 else "floats"]


W_T = (10.0, 1.0)      # tungsten putty
PB = (11.34, 0.62)     # lead shot, voids filled with epoxy
rows = [
    scenario("All chambers epoxy only (no ballast)", {}),
    scenario("B = tungsten putty  (flat flutter - start here)", {"B": W_T}),
    scenario("B = lead shot + epoxy", {"B": PB}),
    scenario("A + B = tungsten  (nose-down glide/spiral)", {"A": W_T, "B": W_T}),
    scenario("A + B + C = tungsten  (fast drop, current)", {"A": W_T, "B": W_T, "C": W_T}),
]
json.dump(dict(V_solid=V_solid, V_ch=ch, rows=rows), open(f"{OUT}/ballast.json", "w"), indent=1)

# ------------------------------------------------------------- mating face diagram
fig, ax = plt.subplots(figsize=(10, 3.2), dpi=200)
xy = np.asarray(poly.exterior.coords)
ax.fill(xy[:, 0], xy[:, 1], color="#e7ebee", ec="#4b5960", lw=0.8)
ax.plot([0, G.FL], [0, 0], color="#c0392b", lw=1.2)
ax.annotate("wire channel (Ø%.1f) — tie loop at mouth" % (G.WIRE_D + 0.4), (8, 0), (8, -40), fontsize=9,
            arrowprops=dict(arrowstyle="-", lw=0.5), color="#c0392b")
ax.annotate("rear loop at tail fork (chain a 'school')", (G.FL, 0), (G.FL - 70, -40), fontsize=9,
            arrowprops=dict(arrowstyle="-", lw=0.5), color="#c0392b")
for c, cc in zip(G.ballast_chambers(poly), info["chambers"]):
    th = np.linspace(-np.pi / 2, np.pi / 2, 30); r = c["H"] / 2; hl = c["L"] / 2 - r
    sx = np.r_[c["x"] + hl + r * np.cos(th), c["x"] - hl - r * np.cos(th)]
    sy = np.r_[c["y"] + r * np.sin(th), c["y"] - r * np.sin(th)]
    ax.fill(sx, sy, fc="#f2c94c", ec="#8a6d1d", lw=0.8)
    ax.text(c["x"], c["y"] + 1.0, c["name"], ha="center", va="center", fontsize=12, weight="bold", color="#5a4510")
    ax.text(c["x"], c["y"] - 3.6, f'{cc["volume_both_halves_cc"]:.1f} cc', ha="center", fontsize=8.5, color="#5a4510")
for p in info["pins"]:
    ax.add_patch(Circle((p["x"], p["y"]), (G.PIN_D + 0.2) / 2, fc="#2d9cdb", ec="none"))
ax.text(info["pins"][0]["x"], info["pins"][0]["y"] - 7, "pins (1.75 mm filament)", fontsize=8.5, color="#1b6fa0", ha="center")
ax.add_patch(Circle((G.EYE_X, G.EYE_Y), G.EYE_D / 2, fc="none", ec="#4b5960", ls="--", lw=0.6))
ax.text(G.EYE_X, G.EYE_Y + 8.5, f"{G.EYE_D:.0f} mm eye pocket (outer face)", fontsize=8.5, ha="center")
ax.set_aspect("equal"); ax.axis("off")
ax.set_xlim(-4, xy[:, 0].max() + 4); ax.set_ylim(-48, 36)
plt.tight_layout(pad=0.2)
plt.savefig(f"{OUT}/mating_face_diagram.png", facecolor="white")
plt.close()

# ------------------------------------------------------------- PDF
W, H = landscape(letter)
c = canvas.Canvas(f"{OUT}/chub_mackerel_flasher_decals_and_build_sheet.pdf", pagesize=(W, H))
c.setTitle("Chub mackerel throw flasher — decals and build sheet")

# page 1 : decals 1:1
L = Image.open(f"{OUT}/decal_LEFT_flank_600dpi.png")
R = Image.open(f"{OUT}/decal_RIGHT_flank_600dpi.png")
dw, dh = L.size[0] * 25.4 / 600, L.size[1] * 25.4 / 600
x0 = (W / mm - dw) / 2
c.setFont("Helvetica-Bold", 10)
c.drawString(x0 * mm, (H / mm - 10) * mm, "CHUB MACKEREL FLASHER — WATERSLIDE DECALS, 1:1")
c.setFont("Helvetica", 7.5)
c.drawString(x0 * mm, (H / mm - 15) * mm,
             "Print at 100% / 'Actual size' (no fit-to-page) on CLEAR inkjet or laser waterslide paper. White = unprinted = clear film, so the chrome base shows through.")
y1 = H / mm - 22 - dh
c.drawImage(ImageReader(L), x0 * mm, y1 * mm, dw * mm, dh * mm)
c.drawString(x0 * mm, (y1 - 4) * mm, "LEFT flank (snout left)   — trim on the grey line; eye hole is pre-cleared")
y2 = y1 - 10 - dh
c.drawImage(ImageReader(R), x0 * mm, y2 * mm, dw * mm, dh * mm)
c.drawString(x0 * mm, (y2 - 4) * mm, "RIGHT flank (snout right)")
# scale check
yb = y2 - 16
c.setLineWidth(0.8)
c.line(x0 * mm, yb * mm, (x0 + 100) * mm, yb * mm)
for k in range(0, 101, 10):
    c.line((x0 + k) * mm, yb * mm, (x0 + k) * mm, (yb + (2.5 if k % 50 == 0 else 1.5)) * mm)
c.drawString((x0 + 103) * mm, (yb - 1) * mm, "Scale check: this bar must measure exactly 100 mm.   "
             f"Decals are 'unrolled' to fit the curved flanks of the FL {G.FL:.0f} mm model.")
c.showPage()

# page 2 : build sheet
def txt(lines, x, y, size=8, lead=10.5, font="Helvetica"):
    for ln in lines:
        if ln.startswith("**"):
            c.setFont("Helvetica-Bold", size + 1); ln = ln.strip("*")
        else:
            c.setFont(font, size)
        c.drawString(x, y, ln); y -= lead
    return y

m = 14 * mm
c.setFont("Helvetica-Bold", 13)
c.drawString(m, H - 16 * mm, "Pacific chub mackerel throw flasher — build sheet")
c.setFont("Helvetica", 8)
c.drawString(m, H - 21 * mm, f"Fork length {G.FL:.0f} mm · total length {info['total_length']:.0f} mm · "
             f"2 glued halves, each {info['half_bbox_mm'][2]:.0f} mm tall · Scomber japonicus field marks (FAO/FishBase)")
prev = Image.open(f"{OUT}/preview_finished_left_flank.png")
pw = 120
c.drawImage(ImageReader(prev), m, H - 25 * mm - pw * prev.size[1] / prev.size[0] * mm, pw * mm, pw * prev.size[1] / prev.size[0] * mm)
mf = Image.open(f"{OUT}/mating_face_diagram.png")
mh = pw * mf.size[1] / mf.size[0]
ytop = H - 25 * mm - pw * prev.size[1] / prev.size[0] * mm - 3 * mm
c.drawImage(ImageReader(mf), m, ytop - mh * mm, pw * mm, mh * mm)

y = ytop - mh * mm - 6 * mm
y = txt(["**Ballast tuning (estimates, PETG at 100% infill, ~6 g epoxy topcoat)"], m, y)
cols = [0, 62, 77, 94, 110]
c.setFont("Helvetica-Bold", 7.5)
for cx, hd in zip(cols, ["Chambers filled", "Dry wt", "Net in sea", "Sink rate*", "to 10 m"]):
    c.drawString(m + cx * mm, y, hd)
y -= 10
c.setFont("Helvetica", 7.5)
for r in rows:
    for cx, v in zip(cols, r):
        c.drawString(m + cx * mm, y, v)
    y -= 9.5
c.setFont("Helvetica-Oblique", 6.5)
c.drawString(m, y - 2, "*Broadside flutter, Cd≈1.2. Real fall rate varies with how it flutters — test in a pool and tune.")

xr = m + 140 * mm
txt([
    "**1  Print (each half flat-face down, no supports)",
    "PETG or ASA (not PLA: brittle and creeps in sun/salt).",
    "0.12 mm layers (or variable layer height on the flanks),",
    "100% infill or 6+ walls so water can't soak in and change weight.",
    "Print one LEFT and one RIGHT half.",
    "",
    "**2  Rig",
    f"Stainless wire Ø{G.WIRE_D:.1f} mm (or 80-100 lb mono) through the channel,",
    "loop at the mouth (line tie) and a loop at the tail fork.",
    "Fill chambers per the table (tungsten putty or lead shot),",
    "set 5 filament pins, flood chambers + faces with 30-min epoxy,",
    "clamp. Sand the seam and layer lines (240 -> 400 wet).",
    "",
    "**3  Make it reflect",
    "Base the whole fish in mirror chrome: chrome foil tape / foil",
    "leaf, or a mirror-chrome spray over gloss black.",
    "Optional: holographic film on the lower flank only.",
    "",
    "**4  Pattern",
    "Seal the printed decal sheet with 2-3 light clear coats; dry.",
    "Trim, soak, slide on; use decal-setting solution so it hugs",
    "the curve. Seam = dorsal/belly midline. Colour inks over chrome",
    "read as metallic 'candy' blue-green; the clear belly stays bright.",
    "Stick a 12 mm 3D eye (silver/gold iris, black pupil) in each pocket.",
    "",
    "**5  Seal",
    "Two coats of clear 2-part lure epoxy (rotate while it cures).",
    "",
    "**Field use",
    "Toss it a few metres away and let it flutter down on a light line;",
    "B-only flutters and flashes like a dying bait. Chain 2-3 by the",
    "tail loops for a mini 'school'. Check local rules on attractors.",
], xr, H - 30 * mm, size=7.8, lead=10)
c.showPage()
c.save()
print(json.dumps(rows, indent=1))
