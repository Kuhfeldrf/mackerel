"""
Run the v3 strip-model sink test for every ballast setup of every design and
write out/web/sink_data.json for the viewer (nominal, calibrated coefficients).
Robustness results (out/robust_final.json) are attached to the default setups.
usage: python3 sim_all3.py [design-only ...]
"""
import base64, itertools, json, os, sys
import numpy as np
from multiprocessing import Pool
import fish3, sim3

CFG = json.load(open("out/design_choice.json"))       # chosen charges / defaults per cavity design
CAVITY_DESIGNS = ("wounded", "scurve")


def job(a):
    design, fills = a
    if design in CAVITY_DESIGNS:
        hc = [c["cc"] for c in fish3.chambers_for(design) if c["name"] == "HEAD"][0]
        fd = {}
        for k in fills:
            if k.startswith("HEAD@"):
                fd["HEAD"] = int(k.split("@")[1]) / (hc * 10)
            else:
                fd[k] = 1.0
        body = fish3.make_body(design, fd)
    else:
        body = fish3.make_body(design, set(fills))
    fr = fish3.run(body)
    m = fish3.metrics(fr, body)
    key = "+".join(sorted(fills))
    m["design"] = design; m["fills"] = key or "none"
    return design, key, fr.astype(np.float32), m


def jobs():
    out = []
    for d in CAVITY_DESIGNS:
        for g in CFG[d]["charges"]:
            for gut in (False, True):
                out.append((d, tuple(["HEAD@%d" % g] + (["GUT"] if gut else []))))
    web = json.load(open("out/web/meta.json"))
    for d in ("curled", "straight"):
        names = [c["name"] for c in web[d]["chambers"]]
        for k in range(len(names) + 1):
            for combo in itertools.combinations(names, k):
                out.append((d, tuple(sorted(combo))))
    return out


if __name__ == "__main__":
    J = jobs()
    data = dict(hz=20, model=dict(name="strip v3", coef=sim3.COEF), runs={})
    only = [a[:-5] for a in sys.argv if a.endswith("-only")]
    if only and os.path.exists("out/web/sink_data.json"):
        old = json.load(open("out/web/sink_data.json"))
        data["runs"] = {k: v for k, v in old["runs"].items() if k.split(":")[0] not in only}
        J = [j for j in J if j[0] in only]
    print(len(J), "runs", flush=True)
    with Pool(2) as pool:
        for design, key, fr, m in pool.imap_unordered(job, J):
            data["runs"][f"{design}:{key}"] = dict(n=len(fr), rg=m["rg_mm"], summary=m, b64=base64.b64encode(fr.tobytes()).decode())
            print(design, key, {k: m[k] for k in ("net_g", "t10", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    if os.path.exists("out/robust_final.json"):
        data["robust"] = json.load(open("out/robust_final.json"))
    json.dump(data, open("out/web/sink_data.json", "w"))
    print("ALL_DONE", flush=True)
