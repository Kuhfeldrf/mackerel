"""Slow head-first spiral tuning: head charge, tail kick, optional nose bead."""
import json, sys
from multiprocessing import Pool
import sim2, wounded as W, cavities as CV

SOLID = json.load(open("out/wounded_info.json"))["solid_cc"]
CH = [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind=c["kind"]) for c in CV.cavities()]
HEAD_CC = [c["cc"] for c in CH if c["name"] == "HEAD"][0]


def job(a):
    bend, kick, head_g, nose_g = a
    extra = [(nose_g, (-5.0, 0.0, 0.0), nose_g / 19.3)] if nose_g else None
    P = sim2.build_model(W.Bend(bend, kick), CH, {"HEAD": head_g / (HEAD_CC * 10)}, solid_cc=SOLID, extra=extra)
    fr = sim2.run(P)
    return a, sim2.metrics(fr, P)


if __name__ == "__main__":
    J = [(0, k, h, 0) for k in (12, 20) for h in (33, 36, 40)] if "final" in sys.argv else [(0, k, h, 0) for k in (8, 14, 20) for h in (10, 13, 16)]
    with Pool(2) as p:
        res = p.map(job, J)
    json.dump([[list(a), m] for a, m in res], open("out/sweep5.json" if "final" in sys.argv else "out/sweep4.json", "w"), indent=1)
    print("SWEEP4_DONE")
