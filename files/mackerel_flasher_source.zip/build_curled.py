"""
'Dead-bait' version: the same chub mackerel, rigidly curled sideways into a U
(like a fish in rigor), split into DORSAL and VENTRAL halves along the flat
frontal plane so both halves still print flat with no supports.

The back lines are engraved as shallow grooves (paint-wash guides) because a
flat decal can't follow the stretched/compressed flanks of a tight curl.
"""
import json
import numpy as np
import triangle as tr
import trimesh
import manifold3d as m3d
import mackerel_geom as G
import pattern as PT

OUT = "out"
FL = G.FL
CURL_DEG = 230.0       # total sideways bend, snout-to-tail (0 = straight, 180 = full U)
ENGRAVE = 0.40         # depth of the engraved back lines (mm); 0 to disable
MAX_AREA = 0.07        # triangle size on the skin (smaller = finer engraving)


# ---------------------------------------------------------------- bend map
_xs = np.linspace(-6, 1.12 * FL, 4000)
_w = G._smooth(0.20 * FL, 0.38 * FL, _xs) * (1 - 0.65 * G._smooth(0.86 * FL, 0.97 * FL, _xs))
_k0 = np.radians(CURL_DEG) / getattr(np, "trapezoid", getattr(np, "trapz", None))(_w, _xs)
_theta = -np.concatenate([[0], np.cumsum((_w[1:] + _w[:-1]) / 2 * np.diff(_xs))]) * _k0
_cx = np.concatenate([[0], np.cumsum(np.cos((_theta[1:] + _theta[:-1]) / 2) * np.diff(_xs))]) + _xs[0]
_cz = np.concatenate([[0], np.cumsum(np.sin((_theta[1:] + _theta[:-1]) / 2) * np.diff(_xs))])
_cx -= np.interp(0, _xs, _cx); _cz -= np.interp(0, _xs, _cz)
MIN_RADIUS = 1 / (_k0 * _w.max())


def bend(P):
    P = np.asarray(P, float)
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    th = np.interp(x, _xs, _theta)
    X = np.interp(x, _xs, _cx) - z * np.sin(th)
    Z = np.interp(x, _xs, _cz) + z * np.cos(th)
    return np.c_[X, y, Z]


# ---------------------------------------------------------------- straight skin
def skin():
    poly = G.outline()
    ring = np.asarray(poly.exterior.coords)[:-1]
    n = len(ring)
    T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]),
                       f"pq30a{MAX_AREA}")
    V2, F = T["vertices"], T["triangles"]
    p = V2[F]
    ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[ar < 0] = F[ar < 0][:, ::-1]
    x, y = V2[:, 0], V2[:, 1]
    z = G.surface_z(x, y)
    zb, t = G.body_z(x, y)
    groove = ENGRAVE * PT.bar_mask(x, t) * (zb > 1.5)
    return poly, V2, F, z - groove, t


def full_body(V2, F, z):
    n = len(V2)
    verts = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    bnd = np.array([k for k in e if (k[1], k[0]) not in key])
    i, j = bnd[:, 0], bnd[:, 1]
    faces = np.vstack([F, F[:, ::-1] + n, np.c_[j, i, i + n], np.c_[j, i + n, j + n]])
    M = m3d.Manifold(m3d.Mesh(vert_properties=verts.astype(np.float32), tri_verts=faces.astype(np.uint32)))
    assert M.status() == m3d.Error.NoError, M.status()
    return M, verts, faces


def zbody_at(x, y):
    return G.body_z(np.atleast_1d(x), np.atleast_1d(y))[0]


def chamber(name, xc, L):
    """Largest box-ish chamber below the split plane that keeps WALL everywhere."""
    xsamp = np.linspace(xc - L / 2 - 1, xc + L / 2 + 1, 25)
    best = None
    for d in np.arange(4, 30, 0.5):
        if d > G.b_mm(xsamp).min() - G.WALL - 0.5:
            break
        zw = min(zbody_at(xsamp, np.full_like(xsamp, -d)).min(),
                 zbody_at(xsamp, np.zeros_like(xsamp)).min()) - G.WALL
        if zw < 2.5:
            break
        if best is None or zw * d > best[1] * best[0]:
            best = (d, zw)
    d, zw = best
    zw = min(zw, L / 2 - 0.5)
    r = zw
    core = m3d.Manifold.cube([L - 2 * r, 2 * r, d + 0.01]).translate([-(L - 2 * r) / 2, -r, 0])
    c1 = m3d.Manifold.cylinder(d + 0.01, r, r, 48).translate([-(L - 2 * r) / 2, 0, 0])
    c2 = m3d.Manifold.cylinder(d + 0.01, r, r, 48).translate([(L - 2 * r) / 2, 0, 0])
    solid = (core + c1 + c2).rotate([90, 0, 0]).translate([xc, 0.01, 0])   # extrudes toward -y
    vol = ((L - 2 * r) * 2 * r + np.pi * r * r) * d / 1000
    return solid, dict(name=name, x_center=round(xc, 1), depth=round(d, 1), width=round(2 * zw, 1),
                       volume_cc=round(vol, 2))


def build():
    poly, V2, F, z, t = skin()
    body, verts, faces = full_body(V2, F, z)
    cuts = []
    wr = (G.WIRE_D + 0.4) / 2
    cuts.append(m3d.Manifold.cylinder(FL + 4, wr, wr, 24).rotate([0, 90, 0]).translate([-2, 0, 0]))

    # C sits at the bottom of the U (where the body has turned ~half the curl),
    # A and B step forward from it; HEAD is for a nose-down alternative.
    L = 0.066 * FL
    apex = float(np.interp(-np.radians(CURL_DEG) / 2, _theta[::-1], _xs[::-1]))
    apex = min(apex, 0.64 * FL)
    chambers = []
    for name, xc in (("HEAD", 0.165 * FL), ("A", apex - 2 * (L + 3.2)), ("B", apex - (L + 3.2)), ("C", apex)):
        s, info = chamber(name, xc, L if name != "HEAD" else 0.06 * FL)
        cuts.append(s); chambers.append(info)

    pins = []
    for px in (0.075 * FL, 0.255 * FL, 0.40 * FL, 0.70 * FL):
        W = zbody_at(px, -4.0)[0]
        pz = round(0.48 * W, 1)
        if W - pz - (G.PIN_D + 0.2) / 2 < 1.0:
            continue
        for sgn in (1, -1):
            r = (G.PIN_D + 0.2) / 2
            cuts.append(m3d.Manifold.cylinder(8.0, r, r, 24).rotate([90, 0, 0]).translate([px, 4.0, sgn * pz]))
        pins.append(dict(x=round(px, 1), z=pz))

    body = body - m3d.Manifold.batch_boolean(cuts, m3d.OpType.Add)
    body = body.refine_to_length(0.8)
    curled = body.warp_batch(lambda P: bend(P))
    assert curled.status() == m3d.Error.NoError
    dorsal, ventral = curled.split_by_plane([0, 1, 0], 0.0)

    def tm(M):
        mm = M.to_mesh()
        return trimesh.Trimesh(np.asarray(mm.vert_properties)[:, :3], np.asarray(mm.tri_verts), process=True)

    D, Vt, whole = tm(dorsal), tm(ventral), tm(curled)
    rot = trimesh.transformations.rotation_matrix
    D.apply_transform(rot(np.pi / 2, [1, 0, 0]))      # +y (back) -> up
    Vt.apply_transform(rot(-np.pi / 2, [1, 0, 0]))    # -y (belly) -> up
    for m in (D, Vt):
        m.apply_translation(-m.bounds[0])
    D.export(f"{OUT}/curled_mackerel_DORSAL_half.stl")
    Vt.export(f"{OUT}/curled_mackerel_VENTRAL_half.stl")

    info = dict(curl_deg=CURL_DEG, min_bend_radius_mm=round(MIN_RADIUS, 1),
                engrave_mm=ENGRAVE, chambers=chambers, pins=pins,
                dorsal=dict(volume_cc=round(D.volume / 1000, 2), bbox=D.extents.round(1).tolist(), watertight=bool(D.is_watertight)),
                ventral=dict(volume_cc=round(Vt.volume / 1000, 2), bbox=Vt.extents.round(1).tolist(), watertight=bool(Vt.is_watertight)),
                whole_bbox=whole.extents.round(1).tolist())
    # snout-to-tail gap (top view)
    snout = bend(np.array([[0, 0, 0]]))[0]
    tails = bend(np.array([[1.085 * FL, 0, 0], [FL, 0, 0]]))
    info["snout_to_fork_gap_mm"] = round(float(np.hypot(*(tails[1] - snout)[[0, 2]])), 1)
    json.dump(info, open(f"{OUT}/curled_info.json", "w"), indent=1)
    np.savez_compressed(f"{OUT}/_curled_skin.npz", V2=V2, F=F, z=z, t=t)
    return info


if __name__ == "__main__":
    print(json.dumps(build(), indent=1))
