"""Export the head-down variant's viewer data: bend table, cavity meshes, print info."""
import base64, json
import numpy as np
import triangle as tr
import sys
import cavities as CV
NAME = sys.argv[1] if len(sys.argv) > 1 else "wounded"

info = json.load(open(f"out/{NAME}_info.json"))
th = np.load(f"out/web/{NAME}_theta.npy").astype(np.float32)


def coarse_cavity(name, x0, x1, band):
    ring = CV.region(x0, x1, band)
    keep = [0]
    for i in range(1, len(ring)):
        if np.hypot(*(ring[i] - ring[keep[-1]])) > 0.6:
            keep.append(i)
    ring = ring[keep]
    n = len(ring)
    T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]), "pq25a6")
    V2, F = T["vertices"], T["triangles"]
    p = V2[F]
    ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[ar < 0] = F[ar < 0][:, ::-1]
    z = np.maximum(CV.zc(V2[:, 0], V2[:, 1]), CV.ZMIN)
    nv = len(V2)
    V = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    b = np.array([k for k in e if (k[1], k[0]) not in key])
    Fa = np.vstack([F, F[:, ::-1] + nv, np.c_[b[:, 1], b[:, 0], b[:, 0] + nv], np.c_[b[:, 1], b[:, 0] + nv, b[:, 1] + nv]])
    return V.astype(np.float32), Fa.astype(np.uint16)


b64 = lambda a: base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()
cav = []
for c in info["chambers"]:
    V, F = coarse_cavity(c["name"], c["x0"], c["x1"], c["band"])
    cav.append(dict(name=c["name"], kind=c["kind"], cc=c["cc"], centre=c["centre"], v=b64(V), f=b64(F)))
CFG = json.load(open("out/design_choice.json"))[NAME]
w = dict(charges=CFG["charges"], defaultCharge=CFG["default"], bend_deg=info["bend_deg"], kick_deg=info["kick_deg"], solid_cc=info["solid_cc"], theta=b64(th),
         chambers=cav, halves=dict(back=info["back"]["bbox"], belly=info["belly"]["bbox"]), whole=info["whole_bbox"])
open(f"out/web/{NAME}_data.js", "w").write(f"window.FISH.{NAME}=" + json.dumps(w, separators=(",", ":")) + ";\n")
print("wounded_data.js KB", len(json.dumps(w)) // 1024)
