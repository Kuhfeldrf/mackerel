"""One-piece print: solid PLA + sealed internal air voids (rear body) + lead slug between the eyes."""
import json, sys
from multiprocessing import Pool
import numpy as np
import fish3, sim2, sim3, cavities as CV, wounded as W, mackerel_geom as G

AIR = [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind="air") for c in CV.cavities() if c["kind"] == "air"]


def body_for(p, coef=None, coat=6.0, rho_scale=1.0, lead_dx=0.0):
    bend = W.BendSegments([(p["bend"], 0.30, 0.66, 0.10), (p["kick"], 0.83, 0.94, 0.04)])
    extra = [(p["lead"], (G.EYE_X + lead_dx, G.EYE_Y, 0.0), p["lead"] / 11.34)] if p["lead"] else None
    # build_model assumes PETG*0.97 ~ 1.23 g/cc, close to solid PLA
    return fish3.make_body("wounded", {}, coef=coef, coat_g=coat, extra=extra, bend=bend, chambers=AIR)


def job(p):
    b = body_for(p)
    fr = fish3.run(b)
    m = fish3.metrics(fr, b)
    ok, ch = fish3.target_score(m)
    return p, m, ok, ch


if __name__ == "__main__":
    J = [dict(bend=30, kick=k, lead=l) for k in (10, 20) for l in (7, 10)] + [dict(bend=40, kick=10, lead=10), dict(bend=30, kick=20, lead=4)]
    with Pool(2) as pool:
        for p, m, ok, ch in pool.imap_unordered(job, J):
            print(p, "OK" if ok else "--", [k for k, v in ch.items() if not v],
                  {k: m[k] for k in ("net_g", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    print("AIR_DONE")
