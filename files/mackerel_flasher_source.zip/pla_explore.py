"""All-PLA (no ballast, no air) shape exploration."""
import sys
from multiprocessing import Pool
import fish3, wounded as W, build_curled as BC


def shape(kind, p):
    if kind == "W":
        return W.BendSegments([(p["bend"], 0.30, 0.66, 0.10), (p["kick"], 0.83, 0.94, 0.04)]) if (p["bend"] or p["kick"]) else None
    if kind == "S":
        sc = p["scale"]
        segs = [(95.0 * sc, 0.17, 0.51, 0.12), (-120.0 * sc, 0.52, 0.93, 0.12)]
        if p.get("kick"):
            segs.append((p["kick"], 0.93, 0.99, 0.025))
        return W.BendSegments(segs)
    if kind == "U":
        return BC.bend


def job(a):
    kind, p = a
    body = fish3.make_uniform_body(shape(kind, p), rho_p=1220.0, coat_g=p.get("coat", 0.0))
    fr = fish3.run(body)
    m = fish3.metrics(fr, body)
    ok, ch = fish3.target_score(m)
    return kind, p, m, ok, ch


if __name__ == "__main__":
    if "w3" in sys.argv:
        J = [("W", dict(bend=b, kick=k)) for b in (33, 36, 40) for k in (0, -10)]
    elif "s2" in sys.argv:
        J = [("S", dict(scale=s, kick=k)) for s in (0.85, 1.0) for k in (8, 15, 25)] + [("S", dict(scale=1.0, kick=-15))]
    else:
        J = [("W", dict(bend=b, kick=k)) for b in (0, 20, 30, 45) for k in (0, 20, 35)]
        J += [("S", dict(scale=1.0)), ("S", dict(scale=0.7)), ("U", {})]
    with Pool(2) as pool:
        for kind, p, m, ok, ch in pool.imap_unordered(job, J):
            print(kind, p, "OK" if ok else "--", [k for k, v in ch.items() if not v],
                  {k: m[k] for k in ("net_g", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    print("PLA_DONE")
