"""Export compact mesh + textures + metadata for the web 3D viewer."""
import base64, io, json
import numpy as np
import triangle as tr
from PIL import Image
import mackerel_geom as G
import pattern as PT

FL = G.FL
OUT = "out/web"
import os
os.makedirs(OUT, exist_ok=True)

poly = G.outline()
ring = np.asarray(poly.exterior.coords)[:-1]
n = len(ring)
T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]), "pq30a0.45")
V2, F = T["vertices"], T["triangles"]
p = V2[F]
ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
F[ar < 0] = F[ar < 0][:, ::-1]
z = G.surface_z(V2[:, 0], V2[:, 1], details=False)
e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
key = {tuple(k) for k in e}
bnd = np.array([k for k in e if (k[1], k[0]) not in key])
print("verts", len(V2), "tris", len(F), "boundary", len(bnd))
assert 2 * len(V2) + 2 * len(V2) < 65536 or True

X0, Y0, X1, Y1 = poly.bounds
pad = 1.0
X0, Y0, X1, Y1 = X0 - pad, Y0 - pad, X1 + pad, Y1 + pad


def b64(a):
    return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()


# ---------------------------------------------------------------- textures
TW, TH = 4096, 1024
xs = X0 + (np.arange(TW) + 0.5) / TW * (X1 - X0)
ys = Y1 - (np.arange(TH) + 0.5) / TH * (Y1 - Y0)       # row 0 = top (v = 1)
silver = np.array([0.93, 0.95, 0.97])
albedo = np.zeros((TH, TW, 3))
bump_s = np.zeros((TH, TW))
bump_c = np.zeros((TH, TW))
from matplotlib.path import Path
path = Path(np.asarray(poly.buffer(1.5).exterior.coords))
for r0 in range(0, TH, 64):
    yy, xx = np.meshgrid(ys[r0:r0 + 64], xs, indexing="ij")
    xf, yf = xx.ravel(), yy.ravel()
    zb, t = G.body_z(xf, yf)
    inside = path.contains_points(np.c_[xf, yf])
    is_fin = (np.abs(t) >= 1) | (xf > G.BODY_END_U * FL) | (zb < 0.05)
    rgb, a = PT.colour(xf, yf, t, is_fin)
    a = np.where(inside, a, 0)
    eye = np.hypot(xf - G.EYE_X, yf - G.EYE_Y) < G.EYE_D / 2 + 0.6
    filt = (1 - a[:, None]) + a[:, None] * np.clip(rgb * 1.35, 0, 1)
    albedo[r0:r0 + 64] = (silver * filt).reshape(len(yy), TW, 3)
    dz = G.surface_z(xf, yf, True) - G.surface_z(xf, yf, False)
    dz = np.where(eye | ~inside, 0, dz)
    bump_s[r0:r0 + 64] = dz.reshape(len(yy), TW)
    eng = 0.4 * PT.bar_mask(xf, t) * (zb > 1.5)
    bump_c[r0:r0 + 64] = (dz - eng).reshape(len(yy), TW)


def jpg(arr, q):
    im = Image.fromarray(np.clip(arr * 255, 0, 255).astype(np.uint8))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=q, optimize=True)
    return buf.getvalue()


tex = jpg(albedo, 86)
lo, hi = -0.8, 0.8
bs = jpg(np.clip((bump_s - lo) / (hi - lo), 0, 1), 90)
bc = jpg(np.clip((bump_c - lo) / (hi - lo), 0, 1), 90)
open(f"{OUT}/albedo_preview.jpg", "wb").write(tex)
print("tex KB", len(tex) // 1024, "bump KB", len(bs) // 1024, len(bc) // 1024)

# ---------------------------------------------------------------- metadata
mi = json.load(open("out/model_info.json"))
ci = json.load(open("out/curled_info.json"))
NR, NSG = 24, 48
rr = (G.EYE_D / 2) * np.arange(NR + 1) / NR
aa = 2 * np.pi * np.arange(NSG) / NSG
ex = G.EYE_X + rr[:, None] * np.cos(aa)[None]
ey = G.EYE_Y + rr[:, None] * np.sin(aa)[None]
eye_base = G.surface_z(ex.ravel(), ey.ravel(), details=False).reshape(ex.shape)
zeye = float(G.body_z(np.array([G.EYE_X]), np.array([G.EYE_Y]))[0][0])
data = dict(
    FL=FL, bounds=[X0, Y0, X1, Y1],
    eye=dict(x=G.EYE_X, y=G.EYE_Y, z=zeye, d=G.EYE_D, nr=NR, nseg=NSG, base=[round(float(v), 3) for v in eye_base.ravel()]),
    straight=dict(
        solid_cc=round(2 * mi["half_volume_cc"], 2), side_area_mm2=mi["side_area_mm2"],
        length=mi["total_length"], height=mi["height_with_fins"],
        chambers=[dict(name=c["name"], x=c["x_center"], y=round(-0.012 * FL, 2), L=round(0.072 * FL, 2),
                       H=round(0.060 * FL, 2), d=c["depth_per_half"], cc=c["volume_both_halves_cc"])
                  for c in mi["chambers"]],
        halves=dict(size=mi["half_bbox_mm"])),
    curled=dict(
        curl_deg=ci["curl_deg"],
        solid_cc=round(ci["dorsal"]["volume_cc"] + ci["ventral"]["volume_cc"], 2),
        chambers=[dict(name=c["name"], x=c["x_center"], depth=c["depth"], width=c["width"],
                       L=round((0.06 if c["name"] == "HEAD" else 0.066) * FL, 2), cc=c["volume_cc"])
                  for c in ci["chambers"]],
        halves=dict(dorsal=ci["dorsal"]["bbox"], ventral=ci["ventral"]["bbox"]),
        gap=ci["snout_to_fork_gap_mm"]),
    mesh=dict(nv=len(V2), nf=len(F), nb=len(bnd),
              xy=b64(V2.astype(np.float32)), z=b64(z.astype(np.float32)),
              f=b64(F.astype(np.uint16 if len(V2) * 4 < 65536 else np.uint32)),
              b=b64(bnd.astype(np.uint16 if len(V2) * 4 < 65536 else np.uint32)),
              idx32=bool(len(V2) * 4 >= 65536)),
)
js = "window.FISH=" + json.dumps(data) + ";\n"
js += "window.FISH_TEX='data:image/jpeg;base64," + base64.b64encode(tex).decode() + "';\n"
js += "window.FISH_BUMP_S='data:image/jpeg;base64," + base64.b64encode(bs).decode() + "';\n"
js += "window.FISH_BUMP_C='data:image/jpeg;base64," + base64.b64encode(bc).decode() + "';\n"
open(f"{OUT}/fish_data.js", "w").write(js)
print("data.js KB", len(js) // 1024)
print(json.dumps({k: v for k, v in data.items() if k != "mesh"}, indent=1))
