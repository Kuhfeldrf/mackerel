"""Z-buffered previews of the curled flasher (finished look + print layout)."""
import numpy as np
import trimesh
from PIL import Image
import mackerel_geom as G
import pattern as PT
import build_curled as BC

OUT = "out"


def finished_colours(V2, z, t):
    x, y = V2[:, 0], V2[:, 1]
    zb, _ = G.body_z(x, y)
    poly_fin = (np.abs(t) >= 1) | (x > G.BODY_END_U * G.FL) | (zb < 0.05)
    rgb, a = PT.colour(x, y, t, poly_fin)
    # 3D eye
    d = np.hypot(x - G.EYE_X, y - G.EYE_Y)
    eye = d < G.EYE_D / 2
    return rgb, a, eye, d


def splat(V, F, attrs, right, up, toward, px, n=7):
    P = np.c_[V @ right, V @ up]
    depth = V @ toward
    ab = np.array([(i / n, j / n) for i in range(n + 1) for j in range(n + 1 - i)])
    w = np.c_[ab, 1 - ab.sum(1)]                       # barycentric weights
    xmin, ymin = P.min(0) - 2
    W = int((P[:, 0].max() + 2 - xmin) / px) + 1
    H = int((P[:, 1].max() + 2 - ymin) / px) + 1
    best_d = np.full(W * H, -np.inf)
    out = {k: np.zeros((W * H,) + attrs[k].shape[1:]) for k in attrs}
    for s in range(0, len(F), 60000):
        f = F[s:s + 60000]
        sp = np.einsum("kv,fvd->fkd", w, P[f]).reshape(-1, 2)
        sd = np.einsum("kv,fv->fk", w, depth[f]).ravel()
        ix = ((sp[:, 0] - xmin) / px).astype(int)
        iy = H - 1 - ((sp[:, 1] - ymin) / px).astype(int)
        idx = iy * W + ix
        order = np.lexsort((-sd, idx))
        u, first = np.unique(idx[order], return_index=True)
        sel = order[first]
        better = sd[sel] > best_d[u]
        u, sel = u[better], sel[better]
        best_d[u] = sd[sel]
        fi, ki = sel // len(w), sel % len(w)
        for k, A in attrs.items():
            vals = A[f[fi]]
            wk = w[ki][:, :, None] if A.ndim == 2 else w[ki]
            out[k][u] = (vals * wk).sum(1)
    mask = np.isfinite(best_d)
    return {k: v.reshape((H, W) + v.shape[1:]) for k, v in out.items()}, mask.reshape(H, W)


def shade_finished(img, mask, world_up, view_dir, bg_top="#1a5577", bg_bot="#08263a"):
    n = img["n"] / np.maximum(np.linalg.norm(img["n"], axis=-1, keepdims=True), 1e-9)
    facing = np.sign((n @ view_dir))[..., None]
    n = n * np.where(facing == 0, 1, facing)
    upd = n @ world_up
    env = 0.28 + 0.6 * ((upd + 1) / 2) ** 1.6
    L = world_up * 0.7 + view_dir * 0.6 + np.cross(world_up, view_dir) * 0.3
    L /= np.linalg.norm(L)
    h = L + view_dir; h /= np.linalg.norm(h)
    spec = np.clip(n @ h, 0, 1) ** 50
    chrome = env[..., None] * PT.hexc("#d9e2e8") + spec[..., None] * 0.8
    a = np.clip(img["a"], 0, 1)[..., None]
    filt = (1 - a) + a * np.clip(img["rgb"] * 1.35, 0, 1)
    col = np.clip(chrome * filt + 0.2 * spec[..., None], 0, 1)
    eye = img["eye"] > 0.5
    d = img["d"]
    r = G.EYE_D / 2
    ecol = np.where((d < r * 0.55)[..., None], 0.03, np.array([0.80, 0.74, 0.52]) * (0.6 + 0.4 * env[..., None]))
    ecol = np.clip(ecol + spec[..., None] * 0.9, 0, 1)
    col = np.where(eye[..., None], ecol, col)
    Hh = col.shape[0]
    g = np.linspace(0, 1, Hh)[:, None, None]
    bg = PT.hexc(bg_top) * (1 - g) + PT.hexc(bg_bot) * g
    return np.where(mask[..., None], col, bg)


def main():
    sk = np.load(f"{OUT}/_curled_skin.npz")
    V2, F, z, t = sk["V2"], sk["F"], sk["z"], sk["t"]
    n = len(V2)
    Vs = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    bnd = np.array([k for k in e if (k[1], k[0]) not in key])
    i, j = bnd[:, 0], bnd[:, 1]
    Fs = np.r_[F, F[:, ::-1] + n, np.c_[j, i, i + n], np.c_[j, i + n, j + n]]
    rgb, a, eye, d = finished_colours(V2, z, t)
    Vb = BC.bend(Vs)
    m = trimesh.Trimesh(Vb, Fs, process=False)
    attrs = dict(rgb=np.r_[rgb, rgb], a=np.r_[a, a], eye=np.r_[eye, eye].astype(float),
                 d=np.r_[d, d], n=m.vertex_normals)
    world_up = np.array([0, 1.0, 0])
    views = {
        "curled_preview_3q": (25, 35),     # (elevation, azimuth) degrees
        "curled_preview_top": (89.5, 0),
    }
    imgs = []
    for name, (el, az) in views.items():
        e, aa = np.radians(el), np.radians(az)
        toward = np.array([np.cos(e) * np.sin(aa), np.sin(e), np.cos(e) * np.cos(aa)])
        right = np.cross(world_up, toward); right /= np.linalg.norm(right)
        up = np.cross(toward, right)
        img, mask = splat(Vb, Fs, attrs, right, up, toward, px=0.11)
        bgs = ("#1a5577", "#08263a") if "3q" in name else ("#c9dde6", "#7fa9bd")
        col = shade_finished(img, mask, world_up, toward, *bgs)
        imgs.append(Image.fromarray((col * 255).astype(np.uint8)))
    # side by side
    h = max(i.size[1] for i in imgs)
    imgs = [i.resize((int(i.size[0] * h / i.size[1]), h)) for i in imgs]
    canvas = Image.new("RGB", (sum(i.size[0] for i in imgs) + 20, h), (8, 38, 58))
    xo = 0
    for i in imgs:
        canvas.paste(i, (xo, 0)); xo += i.size[0] + 20
    canvas.save(f"{OUT}/curled_preview.png")

    # print layout render (grey)
    tiles = []
    for fn in ("curled_mackerel_DORSAL_half.stl", "curled_mackerel_VENTRAL_half.stl"):
        mm = trimesh.load(f"{OUT}/{fn}")
        up_ = np.array([0, 0, 1.0])
        e, aa = np.radians(40), np.radians(-30)
        toward = np.array([np.cos(e) * np.cos(aa), np.cos(e) * np.sin(aa), np.sin(e)])
        right = np.cross(up_, toward); right /= np.linalg.norm(right)
        up = np.cross(toward, right)
        img, mask = splat(mm.vertices, mm.faces, dict(n=mm.vertex_normals), right, up, toward, px=0.15, n=5)
        nn = img["n"] / np.maximum(np.linalg.norm(img["n"], axis=-1, keepdims=True), 1e-9)
        L = 0.5 * up + 0.7 * toward + 0.3 * right; L /= np.linalg.norm(L)
        s = 0.25 + 0.75 * np.clip(nn @ L, 0, 1)
        col = np.where(mask[..., None], s[..., None] * np.array([0.78, 0.80, 0.83]), 1.0)
        tiles.append(Image.fromarray((col * 255).astype(np.uint8)))
    h = max(i.size[1] for i in tiles)
    canvas = Image.new("RGB", (sum(i.size[0] for i in tiles) + 30, h), "white")
    xo = 0
    for i in tiles:
        canvas.paste(i, (xo, 0)); xo += i.size[0] + 30
    canvas.save(f"{OUT}/curled_print_layout.png")


if __name__ == "__main__":
    main()
