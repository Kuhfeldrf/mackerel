"""
Robustness test: run a candidate design across model-coefficient uncertainty
(ranges from the plate calibration), build variation and toss attitude, and
report how often it achieves the target action.
"""
import json, sys
from multiprocessing import Pool
import numpy as np
import fish3, sim3
from explore3 import variant, HEAD_CC

RANGES = dict(CT=(0.7, 1.2), CR=(0.8, 1.5), CD0=(0.12, 0.35), CD90=(1.6, 2.2), Ca=(0.85, 1.1),
              Crot=(0.8, 2.0), Cf=(0.006, 0.02), Cnose=(0.1, 0.4), KTE=(0.5, 1.2))
K = 12


def samples(k=K, seed=11):
    rng = np.random.default_rng(seed)
    out = []
    # Latin-hypercube style: stratify each coefficient
    strata = {n: rng.permutation(k) for n in RANGES}
    for i in range(k):
        coef = {n: lo + (hi - lo) * (strata[n][i] + rng.random()) / k for n, (lo, hi) in RANGES.items()}
        axis = rng.normal(size=3); axis /= np.linalg.norm(axis)
        out.append(dict(coef=coef, dg=float(rng.uniform(-2, 2)), coat=float(rng.uniform(3, 9)),
                        dx=float(rng.uniform(-6, 2)), toss_axis=axis.tolist(), toss_deg=float(rng.uniform(0, 70)),
                        v_scale=float(rng.uniform(0.5, 1.5))))
    return out


def one(args):
    kind, p, smp = args
    design, bend = variant(kind, p)
    g = max(0.0, p["g"] + smp["dg"])
    body = fish3.make_body(design, {"HEAD": g / (HEAD_CC * 10)}, coef=smp["coef"], coat_g=smp["coat"],
                           putty_dx=smp["dx"], bend=bend)
    R0 = sim3.rot(smp["toss_axis"], smp["toss_deg"]) @ fish3.R_START
    v0 = np.array([0.7, -0.25, 0.15]) * smp["v_scale"]
    try:
        fr = fish3.run(body, R0=R0, v0=v0)
    except RuntimeError:
        return None
    m = fish3.metrics(fr, body)
    ok, ch = fish3.target_score(m)
    return dict(m=m, ok=ok, checks=ch)


def evaluate(cands, k=K):
    S = samples(k)
    jobs = [(kind, p, s) for kind, p in cands for s in S]
    with Pool(2) as pool:
        res = pool.map(one, jobs)
    out = []
    for i, (kind, p) in enumerate(cands):
        rs = [r for r in res[i * k:(i + 1) * k] if r]
        ok = sum(r["ok"] for r in rs)
        each = {c: sum(r["checks"][c] for r in rs) for c in rs[0]["checks"]} if rs else {}
        q = lambda key: np.percentile([r["m"][key] for r in rs], [10, 50, 90]).round(2).tolist()
        out.append(dict(kind=kind, p=p, success=f"{ok}/{len(rs)}", each=each,
                        sink=q("sink"), head_down=q("head_down"), rock=np.percentile([1.4 * max(r["m"]["roll_osc"], r["m"]["head_down_osc"]) for r in rs], [10, 50, 90]).round(1).tolist(),
                        turn_s=np.percentile([360 / max(abs(r["m"]["yaw_rate"]), 1) for r in rs], [10, 50, 90]).round(1).tolist()))
        print(json.dumps(out[-1]), flush=True)
    return out


if __name__ == "__main__":
    cands = json.loads(sys.argv[1])
    res = evaluate([(c[0], c[1]) for c in cands])
    json.dump(res, open(sys.argv[2], "w"), indent=1)
    print("ROBUST_DONE")
