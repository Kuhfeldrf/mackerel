"""
Sink tests for the one-piece PLA prints (calibrated strip model) -> out/web/sink_data.json
  wounded : 35 deg bend, 10 deg tail kick, sealed air voids, lead slug between the eyes (LEAD@g)
  scurve, curled, straight : solid PLA, no ballast
"""
import base64, json
import numpy as np
from multiprocessing import Pool
import fish3, wounded as W, build_curled as BC, mackerel_geom as G
from onepiece_air import AIR

HEAD = dict(bend=35, kick=10)
LEAD = [8, 10, 11, 12, 13]
LEAD_DEFAULT = 10
COAT = 6.0          # paint + epoxy topcoat (g), middle of the 3-9 g tested range
RHO_PLA = 1220.0


def wounded_body(g):
    bend = W.BendSegments([(HEAD["bend"], 0.30, 0.66, 0.10), (HEAD["kick"], 0.83, 0.94, 0.04)])
    extra = [(g, (G.EYE_X, G.EYE_Y, 0.0), g / 11.34)]
    return fish3.make_body("wounded", {}, coat_g=COAT, extra=extra, bend=bend, chambers=AIR, rho_p=RHO_PLA / 1000)


def solid_body(design):
    bend = {"scurve": W.BendSegments(W.S_SEGMENTS), "curled": BC.bend, "straight": None}[design]
    return fish3.make_uniform_body(bend, rho_p=RHO_PLA, coat_g=COAT)


def job(a):
    design, key = a
    body = wounded_body(int(key.split("@")[1])) if design == "wounded" else solid_body(design)
    fr = fish3.run(body)
    m = fish3.metrics(fr, body)
    m["design"] = design; m["fills"] = key or "none"
    return design, key, fr.astype(np.float32), m


if __name__ == "__main__":
    J = [("wounded", f"LEAD@{g}") for g in LEAD] + [("scurve", ""), ("curled", ""), ("straight", "")]
    data = dict(hz=20, model=dict(name="strip v3 (calibrated)", coat_g=COAT, rho_pla=RHO_PLA), runs={})
    with Pool(2) as pool:
        for design, key, fr, m in pool.imap_unordered(job, J):
            data["runs"][f"{design}:{key}"] = dict(n=len(fr), rg=m["rg_mm"], summary=m, b64=base64.b64encode(fr.tobytes()).decode())
            print(design, key, {k: m[k] for k in ("net_g", "dry_g", "t10", "sink", "head_down", "roll_osc", "yaw_rate", "rg_mm", "cb_mm")}, flush=True)
    ro = json.load(open("out/robust_onepiece.json"))
    rh = [r for r in ro if r["p"] == {"bend": 35, "kick": 10, "lead": 10}][0]
    rs = json.load(open("out/robust_pla.json"))[0]
    data["robust"] = {"wounded": dict(key=f"LEAD@{LEAD_DEFAULT}", success=rh["success"], sink=rh["sink"]),
                      "scurve": dict(key="", success=f'{rs["each"]["head_first"]}/12 head-first, {rs["each"]["slow"]}/12 slow, {rs["each"]["light_flutter"]}/12 light flutter (no spiral):',
                                     sink=rs["sink"], note=True)}
    json.dump(data, open("out/web/sink_data.json", "w"))
    print("ALL_DONE", flush=True)
