"""
Pacific chub mackerel (Scomber japonicus) throw-flasher -- shared geometry.

All units mm. Fish lies along +x with the snout at x=0 and the tail fork at x=FL.
y is up (dorsal +), z is the thickness of ONE half (the left flank faces +z).
Each half prints flat-face-down; the two halves glue together on z=0.

Change the parameters below and re-run build_all.py to regenerate STLs + decals.
"""
import numpy as np
from scipy.interpolate import PchipInterpolator
from shapely.geometry import Polygon
from shapely.ops import unary_union

# ----------------------------------------------------------------- parameters
FL = 230.0            # fork length (snout tip to tail fork). Total length ~1.085*FL
WIDTH_RATIO = 0.40    # body half-width / body half-depth on the flanks (real fish ~0.65;
                      # flatter = slower, wider flutter and a bigger flash panel)
SECTION_P = 2.5       # cross-section superellipse exponent (2 = ellipse, higher = flatter flanks)
FIN_T = 1.2           # fin thickness per half (2.4 mm glued)
EYE_D = 12.0          # 3D stick-on lure eye diameter
EYE_RECESS = 1.0      # eye pocket depth
WIRE_D = 1.0          # through-wire (stainless 0.8-1.0 mm) -> channel is WIRE_D + 0.4
PIN_D = 1.75          # alignment pins = offcuts of 1.75 mm filament
WALL = 1.8            # minimum shell over the ballast chambers

# ----------------------------------------------------------- side profile (u = x/FL)
_U = [0.000, 0.010, 0.030, 0.060, 0.120, 0.200, 0.300, 0.380, 0.480, 0.580,
      0.680, 0.780, 0.850, 0.880, 0.905, 0.930]
_A = [0.000, 0.012, 0.030, 0.046, 0.066, 0.084, 0.095, 0.098, 0.092, 0.075,
      0.052, 0.032, 0.022, 0.020, 0.023, 0.028]          # dorsal half-depth / FL
_B = [0.000, 0.007, 0.020, 0.035, 0.058, 0.080, 0.092, 0.094, 0.088, 0.072,
      0.050, 0.031, 0.021, 0.019, 0.022, 0.027]          # ventral half-depth / FL
_a = PchipInterpolator(_U, _A)
_b = PchipInterpolator(_U, _B)
BODY_END_U = 0.930

# half-width factor along the body (heads and peduncles are rounder)
_KU = [0.00, 0.10, 0.25, 0.40, 0.65, 0.80, 0.90, 0.93]
_KV = [0.60, 0.52, 0.45, WIDTH_RATIO, WIDTH_RATIO + 0.02, 0.58, 0.80, 0.80]
_k = PchipInterpolator(_KU, _KV)


def a_mm(x):
    u = np.clip(np.asarray(x) / FL, 0, BODY_END_U)
    return _a(u) * FL


def b_mm(x):
    u = np.clip(np.asarray(x) / FL, 0, BODY_END_U)
    return _b(u) * FL


def center_mm(x):
    return (a_mm(x) - b_mm(x)) / 2.0


def halfdepth_mm(x):
    return (a_mm(x) + b_mm(x)) / 2.0


# ----------------------------------------------------------------- landmarks
EYE_X = 0.085 * FL
EYE_Y = 0.012 * FL
OPERC_X = 0.262 * FL        # rear edge of gill cover at mid-height


def operc_x(t):
    return FL * (0.262 - 0.040 * t ** 2)


def preop_x(t):
    return FL * (0.195 - 0.030 * t ** 2)


PECT_BASE = (0.272 * FL, None)   # y set relative to body below
PECT_TIP = (0.370 * FL, None)


def pect_points():
    x0, x1 = PECT_BASE[0], PECT_TIP[0]
    y0 = center_mm(x0) + 0.30 * halfdepth_mm(x0)
    y1 = center_mm(x1) + 0.18 * halfdepth_mm(x1)
    return (x0, y0), (x1, y1)


# ----------------------------------------------------------------- outline
def _bez(p0, p1, p2, n=40):
    t = np.linspace(0, 1, n)[:, None]
    p0, p1, p2 = map(np.asarray, (p0, p1, p2))
    return (1 - t) ** 2 * p0 + 2 * (1 - t) * t * p1 + t ** 2 * p2


def _fin(points_u):
    """points given as (u, offset/FL, side) with side +1 dorsal / -1 ventral."""
    pts = []
    for u, off, side in points_u:
        x = u * FL
        edge = a_mm(x) if side > 0 else -b_mm(x)
        pts.append((x, edge + side * off * FL))
    # close back through the body so the union overlaps
    xs = [p[0] for p in pts]
    side = points_u[0][2]
    for x in (xs[-1], xs[0]):
        edge = a_mm(x) if side > 0 else -b_mm(x)
        pts.append((x, edge - side * 3.0))
    return Polygon(pts)


def outline():
    xs = np.linspace(0, BODY_END_U * FL, 400)
    top = np.c_[xs, a_mm(xs)]
    bot = np.c_[xs[::-1], -b_mm(xs[::-1])]
    body = Polygon(np.r_[top, bot])

    # caudal fin: deeply forked, fork apex at x = FL
    tip_u = 1.085
    up_lead = _bez((0.880 * FL, a_mm(0.88 * FL) - 1), (0.975 * FL, 0.050 * FL), (tip_u * FL, 0.127 * FL))
    up_trail = _bez((tip_u * FL, 0.127 * FL), (1.035 * FL, 0.055 * FL), (FL, 0.0))
    lo_trail = _bez((FL, 0.0), (1.035 * FL, -0.054 * FL), (tip_u * FL, -0.125 * FL))
    lo_lead = _bez((tip_u * FL, -0.125 * FL), (0.975 * FL, -0.049 * FL), (0.880 * FL, -b_mm(0.88 * FL) + 1))
    caudal = Polygon(np.r_[up_lead, up_trail[1:], lo_trail[1:], lo_lead[1:]])

    fins = [
        # first (spiny) dorsal, partly raised
        _fin([(0.335, 0.0, 1), (0.352, 0.044, 1), (0.392, 0.031, 1), (0.440, 0.013, 1), (0.475, 0.0, 1)]),
        # second dorsal
        _fin([(0.565, 0.0, 1), (0.582, 0.042, 1), (0.603, 0.035, 1), (0.636, 0.008, 1), (0.646, 0.0, 1)]),
        # anal fin (opposite / slightly behind 2nd dorsal)
        _fin([(0.585, 0.0, -1), (0.601, 0.040, -1), (0.622, 0.033, -1), (0.655, 0.008, -1), (0.665, 0.0, -1)]),
        # pelvic fin
        _fin([(0.282, 0.0, -1), (0.322, 0.017, -1), (0.332, 0.012, -1), (0.318, 0.0, -1)]),
    ]
    # 5 dorsal + 5 anal finlets on the caudal peduncle
    for i in range(5):
        s = 0.668 + i * 0.037
        fins.append(_fin([(s, 0.0, 1), (s + 0.030, 0.017, 1), (s + 0.024, 0.0, 1)]))
        s = 0.684 + i * 0.034
        fins.append(_fin([(s, 0.0, -1), (s + 0.028, 0.016, -1), (s + 0.022, 0.0, -1)]))

    poly = unary_union([body, caudal] + fins)
    poly = poly.buffer(0.25, join_style=1).buffer(-0.25, join_style=1)   # tidy tiny slivers
    return poly.simplify(0.05)


# ----------------------------------------------------------------- surface height
def body_z(x, y):
    """Smooth body half-thickness (no fins, no surface detail)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    H = np.maximum(halfdepth_mm(x), 1e-6)
    t = (y - center_mm(x)) / H
    W = _k(np.clip(x / FL, 0, BODY_END_U)) * H
    inside = (np.abs(t) < 1) & (x <= BODY_END_U * FL)
    z = np.zeros_like(x)
    tt = np.clip(np.abs(t), 0, 1)
    z[inside] = W[inside] * (1 - tt[inside] ** SECTION_P) ** (1 / SECTION_P)
    return z, t


def _smooth(e0, e1, v):
    s = np.clip((v - e0) / (e1 - e0), 0, 1)
    return s * s * (3 - 2 * s)


def _seg_dist(px, py, p0, p1):
    (x0, y0), (x1, y1) = p0, p1
    dx, dy = x1 - x0, y1 - y0
    L2 = dx * dx + dy * dy
    s = np.clip(((px - x0) * dx + (py - y0) * dy) / L2, 0, 1)
    return np.hypot(px - (x0 + s * dx), py - (y0 + s * dy)), s


def surface_z(x, y, details=True):
    """Full top-surface height of one half (inside the outline)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    zb, t = body_z(x, y)
    z = np.maximum(zb, FIN_T)

    # thicker spine through the tail so the wire channel has material to the fork
    tail_w = _smooth(0.86 * FL, 0.90 * FL, x)
    spine = FIN_T + (0.95 - 0.25 * _smooth(0.93 * FL, FL, x)) * np.exp(-(y / 2.6) ** 2) * tail_w
    z = np.maximum(z, spine)
    # snout floor so the wire exits through solid material
    z = np.maximum(z, (1.9 - 0.15 * np.abs(y)) * (x < 0.03 * FL))

    if not details:
        return z
    on_body = zb > 0.3

    # gill cover (opercle) edge groove + preopercle groove
    tc = np.clip(t, -1, 1)
    d_op = x - operc_x(tc)
    g = 0.55 * np.exp(-(d_op / 0.55) ** 2) * _smooth(-0.95, -0.80, tc) * (1 - _smooth(0.65, 0.85, tc))
    d_pre = x - preop_x(tc)
    g += 0.30 * np.exp(-(d_pre / 0.5) ** 2) * _smooth(-0.90, -0.70, tc) * (1 - _smooth(0.20, 0.40, tc))
    # mouth line
    d_m, s_m = _seg_dist(x, y, (0.0, -0.004 * FL), (0.074 * FL, -0.022 * FL))
    g += 0.45 * np.exp(-(d_m / 0.45) ** 2) * (1 - _smooth(0.75, 1.0, s_m))
    z = z - g * on_body

    # pectoral fin relief (short, set high on the flank)
    p0, p1 = pect_points()
    d_p, s_p = _seg_dist(x, y, p0, p1)
    r = 3.6 - 2.6 * s_p
    z = z + 0.75 * _smooth(0.0, 0.9, r - d_p) * on_body

    # two small caudal keels each side of the peduncle
    for side in (+1, -1):
        yk = center_mm(x) + side * 0.33 * halfdepth_mm(x)
        win = _smooth(0.845 * FL, 0.865 * FL, x) * (1 - _smooth(0.905 * FL, 0.925 * FL, x))
        z = z + 0.6 * np.exp(-((y - yk) / 0.55) ** 2) * win * on_body

    # flat-bottomed eye pocket for a stick-on 3D eye
    zc, _ = body_z(np.array([EYE_X]), np.array([EYE_Y]))
    floor = zc[0] - EYE_RECESS
    in_eye = np.hypot(x - EYE_X, y - EYE_Y) < (EYE_D / 2 + 0.2)
    z = np.where(in_eye, np.minimum(z, floor), z)
    return z


# ----------------------------------------------------------------- internal features
def ballast_chambers(poly):
    """Three tunable ballast chambers (A fwd, B centre, C aft), centred on the
    side-area centroid so filling B alone gives a flat, fluttering fall."""
    cx = poly.centroid.x
    cy = -0.012 * FL
    L, Hh, gap = 0.072 * FL, 0.060 * FL, 3.5
    out = []
    for name, dx in (("A", -(L + gap)), ("B", 0.0), ("C", L + gap)):
        x0 = cx + dx
        out.append(dict(name=name, x=x0, y=cy, L=L, H=Hh))
    return out


def pin_sites():
    """Alignment-pin holes (x, y) -- kept clear of the wire and chambers."""
    return [(0.150 * FL, -0.022 * FL), (0.205 * FL, 0.030 * FL),
            (0.600 * FL, 0.030 * FL), (0.640 * FL, -0.024 * FL), (0.760 * FL, 0.011 * FL)]
