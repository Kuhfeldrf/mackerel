"""
Sink simulator v2: the v1 model (buoyancy, Newtonian facet drag, skin friction,
added mass + Munk moment) plus a quasi-steady circulation-lift term on the main
flat face (Andersen-Pesavento-Wang style), which produces glide, flutter and
spiral motions that the pure drag model cannot.
"""
import json, sys, itertools, base64
import numpy as np
import triangle as tr
import trimesh
from multiprocessing import Pool
import mackerel_geom as G
import build_curled as BC
import wounded as W
from simulate_sink import qmul, qrot, mat2q, rot, R_REST

RHO_W, GRAV = 1025.0, 9.81
CD, CF, KL = 1.15, 0.008, 0.6
DT, OUT_HZ, T_MAX, DEPTH_STOP = 0.003, 20, 40.0, 10.5
FL = G.FL
WALL = G.WALL


# ------------------------------------------------------------------ chambers
def zb(x, y):
    return G.body_z(np.atleast_1d(np.asarray(x, float)), np.atleast_1d(np.asarray(y, float)))[0]


def chamber_split(name, xc, L, both):
    """Stadium pocket in the x-z plane, extruded along y. both=True straddles the
    split plane (pocket in each half), else it sits in the belly half only."""
    xs = np.linspace(xc - L / 2 - 1, xc + L / 2 + 1, 25)
    best = None
    for d in np.arange(3, 30, 0.5):
        y0, y1 = (-d, d) if both else (-d, 0.0)
        if both and d > min(G.a_mm(xs).min(), G.b_mm(xs).min()) - WALL - 0.5:
            break
        if not both and d > G.b_mm(xs).min() - WALL - 0.5:
            break
        ys = np.linspace(y0, y1, 9)
        zw = min(zb(xs, np.full_like(xs, yy)).min() for yy in ys) - WALL
        if zw < 2.5:
            break
        vol = (y1 - y0) * zw
        if best is None or vol > best[2]:
            best = (d, zw, vol)
    d, zw, _ = best
    zw = min(zw, L / 2 - 0.5)
    y0, y1 = (-d, d) if both else (-d, 0.0)
    vol = ((L - 2 * zw) * 2 * zw + np.pi * zw * zw) * (y1 - y0) / 1000
    return dict(name=name, x=round(xc, 2), y0=round(y0, 2), y1=round(y1, 2), r=round(zw, 2), L=round(L, 2), cc=round(vol, 3))


def wounded_chambers():
    out = []
    for name, xc, L, kind in W.CHAMBERS:
        c = chamber_split(name, xc, L, both=True)
        c["kind"] = kind
        out.append(c)
    return out


# ------------------------------------------------------------------ body model
def coarse_mesh(bend):
    poly = G.outline()
    ring = np.asarray(poly.exterior.coords)[:-1]
    n = len(ring)
    T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]), "pq28a5")
    V2, F = T["vertices"], T["triangles"]
    p = V2[F]
    ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[ar < 0] = F[ar < 0][:, ::-1]
    z = G.surface_z(V2[:, 0], V2[:, 1], details=False)
    nv = len(V2)
    V = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    b = np.array([k for k in e if (k[1], k[0]) not in key])
    Fa = np.vstack([F, F[:, ::-1] + nv, np.c_[b[:, 1], b[:, 0], b[:, 0] + nv], np.c_[b[:, 1], b[:, 0] + nv, b[:, 1] + nv]])
    if bend is not None:
        V = bend(V)
    m = trimesh.Trimesh(V * 1e-3, Fa, process=False)
    assert m.is_watertight
    return m


def build_model(bend, chambers, fills, solid_cc=None, extra=None):
    """chambers: list of dict(name, centre (flat mm), cc)."""
    mesh = coarse_mesh(bend)
    V_mesh = mesh.volume
    V_ch = sum(c["cc"] for c in chambers) * 1e-6
    if solid_cc is None:
        solid_cc = (V_mesh - V_ch) * 1e6
    m_shell = (1.27 * solid_cc * 0.97 + 6.0) * 1e-3
    rho_s = m_shell / (V_mesh - V_ch)
    mp = mesh.mass_properties
    c0 = np.asarray(mp["center_mass"]); I0 = np.asarray(mp["inertia"]) * rho_s
    M = rho_s * V_mesh
    pts = [(M, c0)]
    for c in chambers:
        ctr = np.asarray(c["centre"], float)[None]
        ctr = (bend(ctr) if bend is not None else ctr)[0] * 1e-3
        v = c["cc"] * 1e-6
        pts.append((-rho_s * v, ctr))
        if c.get("kind") == "air":
            dens = 0.0
        else:
            f = fills.get(c["name"], 0.0) if isinstance(fills, dict) else (1.0 if c["name"] in fills else 0.0)
            dens = f * 10000.0 + (1 - f) * 1150.0
        pts.append((dens * v, ctr))
    V_extra = 0.0
    for g, pos, cc in (extra or []):                       # e.g. a tungsten bead on the nose loop
        p_ = np.asarray(pos, float)[None]
        p_ = (bend(p_) if bend is not None else p_)[0] * 1e-3
        pts.append((g * 1e-3, p_)); V_extra += cc * 1e-6
    m = sum(w for w, _ in pts)
    rg = sum(w * c for w, c in pts) / m
    I = I0 + M * ((c0 - rg) @ (c0 - rg) * np.eye(3) - np.outer(c0 - rg, c0 - rg))
    for w, c in pts[1:]:
        r = c - rg; I += w * (r @ r * np.eye(3) - np.outer(r, r))
    ev, E = np.linalg.eigh(I)
    if np.linalg.det(E) < 0:
        E[:, 2] *= -1
    V_disp = solid_cc * 1e-6 + V_ch + V_extra
    fc, fa, fn = mesh.triangles_center, mesh.area_faces, mesh.face_normals
    Bc, Bn = (fc - rg) @ E, fn @ E
    Aproj = np.array([0.5 * np.sum(np.abs(Bn[:, i]) * fa) for i in range(3)])
    Ma = 0.48 * RHO_W * Aproj ** 1.5
    Ia = np.array([0.356 * RHO_W * sum((Aproj[j] / np.pi) ** 2.5 for j in range(3) if j != i) for i in range(3)])
    ip = int(np.argmax(Aproj))
    n_plate = np.eye(3)[ip]
    return dict(m=m, I=ev, E=E, rg=rg, cb_b=(c0 - rg) @ E, V_disp=V_disp, Bc=Bc, Bn=Bn, A=fa, Ma=Ma, Ia=Ia,
                n_plate=n_plate, A_plate=Aproj[ip], net_g=(m - RHO_W * V_disp) * 1000, dry_g=m * 1000)


def deriv(s, P):
    q, v, w = s[3:7], s[7:10], s[10:13]
    R = qrot(q)
    g_b = R.T @ np.array([0, -GRAV, 0])
    Fb = -RHO_W * P["V_disp"] * g_b
    F = P["m"] * g_b + Fb
    Mo = np.cross(P["cb_b"], Fb)
    u = v + np.cross(w, P["Bc"])
    un = np.einsum("ij,ij->i", u, P["Bn"])
    Fp = -(0.5 * RHO_W * CD * P["A"] * np.maximum(un, 0) ** 2)[:, None] * P["Bn"]
    ut = u - un[:, None] * P["Bn"]
    Ft = -(0.5 * RHO_W * CF * P["A"] * np.linalg.norm(ut, axis=1))[:, None] * ut
    Ff = Fp + Ft
    F = F + Ff.sum(0)
    Mo = Mo + np.cross(P["Bc"], Ff).sum(0)
    # circulation lift on the main flat face (acts at the CG; Munk term carries the moment)
    vm = np.linalg.norm(v)
    if KL > 0 and vm > 1e-6:
        vh = v / vm
        n = P["n_plate"]
        c = n @ vh
        nperp = n - c * vh
        npm = np.linalg.norm(nperp)
        if npm > 1e-9:
            sa = abs(c); ca = np.sqrt(max(0.0, 1 - c * c))
            F = F + (-np.sign(c)) * 0.5 * RHO_W * KL * P["A_plate"] * vm * vm * 2 * sa * ca * nperp / npm
    Mt = P["m"] + P["Ma"]; It = P["I"] + P["Ia"]
    dv = (F - np.cross(w, Mt * v)) / Mt
    dw = (Mo - np.cross(w, It * w) - np.cross(v, P["Ma"] * v)) / It
    return np.r_[R @ v, 0.5 * qmul(q, np.r_[0, w]), dv, dw]


R_START = rot([1, 0, 0], 35) @ rot([0, 1, 0], 20) @ R_REST     # tossed in near-flat, a bit rolled and yawed


def run(P):
    R0 = R_START @ P["E"]
    s = np.r_[[0, -0.06, 0], mat2q(R0), R0.T @ np.array([0.7, -0.25, 0.15]), R0.T @ np.array([0.6, 0.3, 0.9])]
    t, frames, nxt = 0.0, [], 0.0
    while t <= T_MAX:
        if t >= nxt - 1e-9:
            frames.append(np.r_[s[:3], mat2q(qrot(s[3:7]) @ P["E"].T)])
            nxt += 1.0 / OUT_HZ
            if -s[1] > DEPTH_STOP:
                break
        k1 = deriv(s, P); k2 = deriv(s + DT / 2 * k1, P); k3 = deriv(s + DT / 2 * k2, P); k4 = deriv(s + DT * k3, P)
        s = s + DT / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        s[3:7] /= np.linalg.norm(s[3:7]); t += DT
        if not np.all(np.isfinite(s)):
            raise RuntimeError("diverged")
    return np.array(frames)


def metrics(fr, P):
    depth = -fr[:, 1]
    tt = np.arange(len(fr)) / OUT_HZ
    t10 = float(np.interp(10.0, depth, tt)) if depth.max() >= 10 else None
    late = slice(int(4 * OUT_HZ), len(fr))                # ignore the first 4 s (entry)
    Rs = np.array([qrot(q) for q in fr[late, 3:]])
    snout = -Rs[:, :, 0]                                     # head direction (fish -x)
    head_down = np.degrees(np.arcsin(np.clip(-snout[:, 1], -1, 1)))
    flank = Rs[:, :, 2]
    roll = np.degrees(np.arccos(np.clip(np.abs(flank[:, 1]), 0, 1)))   # 0 = lying flat on a side
    yaw = np.unwrap(np.arctan2(snout[:, 2], snout[:, 0]))
    yaw_rate = float(np.degrees(np.polyfit(tt[late], yaw, 1)[0])) if len(yaw) > 5 else 0.0
    xz = fr[late][:, [0, 2]]
    sway = float(np.sqrt(((xz - xz.mean(0)) ** 2).sum(1).mean()))
    hd_osc = float(np.std(head_down))
    roll_osc = float(np.std(roll))
    spd = np.diff(depth[late]) * OUT_HZ
    return dict(net_g=round(P["net_g"], 1), dry_g=round(P["dry_g"], 1), t10=None if t10 is None else round(t10, 1),
                sink=round(float(spd.mean()), 3), sink_osc=round(float(spd.std()), 3),
                head_down=round(float(head_down.mean()), 1), head_down_osc=round(hd_osc, 1),
                roll=round(float(roll.mean()), 1), roll_osc=round(roll_osc, 1),
                yaw_rate=round(yaw_rate, 1), sway_m=round(sway, 3), rg_mm=(P["rg"] * 1000).round(2).tolist())


def chamber_list():
    import cavities
    return [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind=c["kind"]) for c in cavities.cavities()]


def sweep_job(args):
    bend_deg, kick_deg, fills = args
    B = W.Bend(bend_deg, kick_deg) if (bend_deg or kick_deg) else None
    fd = dict(fills) if isinstance(fills, tuple) and fills and isinstance(fills[0], tuple) else set(fills)
    P = build_model(B, chamber_list(), fd)
    fr = run(P)
    return (bend_deg, kick_deg, str(fills)), metrics(fr, P)


if __name__ == "__main__":
    jobs = [(b, k, (("HEAD", f),)) for b in (0, 25) for k in (0, 20) for f in (0.25, 0.4)] + [(50, 0, (("HEAD", 0.3),)), (12, 12, (("HEAD", 0.3),))]
    with Pool(2) as pool:
        res = pool.map(sweep_job, jobs)
    for k, m in res:
        print(k, m)
    json.dump([[list(k), m] for k, m in res], open(sys.argv[1] if len(sys.argv) > 1 else "out/sweep2.json", "w"), indent=1)
