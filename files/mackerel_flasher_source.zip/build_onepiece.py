"""
One-piece solid prints (OSU Valley Library: PLA, one STL < 5 MB).
  * whole fish, no split, no internal cavities
  * eye pockets both sides; optional eye-to-eye bore for a lead slug (hidden under the eyes)
  * 2.2 mm line hole top-to-bottom through the head (tie the line here)
  * oriented upright (back up): the body bend lies flat in the print plane, supports only under the belly
usage: python3 build_onepiece.py NAME (W BEND KICK | S | U | STRAIGHT) [BORE_MM]
"""
import json, os, sys
import numpy as np
import trimesh
import manifold3d as m3d
import mackerel_geom as G
import build_curled as BC
import wounded as W

OUT = "out/onepiece"
FL = G.FL
os.makedirs(OUT, exist_ok=True)
LINE_X = 0.045 * FL


def build(name, bend, bore_mm=0.0, air=False):
    BC.MAX_AREA = 0.36
    poly, V2, F, z, t = BC.skin()
    body, _, _ = BC.full_body(V2, F, z)
    cuts = []
    # line hole: vertical (dorsal-ventral) through the head
    cuts.append(m3d.Manifold.cylinder(80, 1.1, 1.1, 20).rotate([90, 0, 0]).translate([LINE_X, 40, 0]))
    if air:                              # sealed internal air voids in the rear body (printed enclosed)
        import cavities as CV
        for c in CV.cavities():
            if c["kind"] == "air":
                cuts.append(CV.manifold_of(c))
    if bore_mm:
        r = bore_mm / 2
        cuts.append(m3d.Manifold.cylinder(40, r, r, 40).translate([G.EYE_X, G.EYE_Y, -20]))
    body = body - m3d.Manifold.batch_boolean(cuts, m3d.OpType.Add)
    if bend is not None:
        body = body.refine_to_length(2.0).warp_batch(lambda P: bend(P))
    mm = body.to_mesh()
    T = trimesh.Trimesh(np.asarray(mm.vert_properties)[:, :3], np.asarray(mm.tri_verts), process=True)
    T.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))   # fish y (back) -> +Z
    T.apply_translation(-T.bounds[0])
    fn = f"{OUT}/{name}_onepiece.stl"
    T.export(fn)
    vol = T.volume / 1000
    info = dict(name=name, file=os.path.basename(fn), MB=round(os.path.getsize(fn) / 1e6, 2), watertight=bool(T.is_watertight),
                bbox_mm=T.extents.round(1).tolist(), volume_cc=round(vol, 2), pla_g_100pct=round(vol * 1.24, 1),
                cost_usd=round(vol * 1.24 * 0.16, 2), bore_mm=bore_mm, sealed_air=air,
                lead_g_fill=round(np.pi * (bore_mm / 2) ** 2 * 2 * float(G.body_z(np.array([G.EYE_X]), np.array([G.EYE_Y]))[0][0]) / 1000 * 11.34, 1) if bore_mm else 0)
    json.dump(info, open(f"{OUT}/{name}_onepiece_info.json", "w"), indent=1)
    return info


def bend_from_args(a):
    kind = a[0]
    if kind == "W":
        b, k = float(a[1]), float(a[2])
        return W.BendSegments([(b, 0.30, 0.66, 0.10), (k, 0.83, 0.94, 0.04)]), a[3:]
    if kind == "S":
        return W.BendSegments(W.S_SEGMENTS), a[1:]
    if kind == "U":
        return BC.bend, a[1:]
    return None, a[1:]


if __name__ == "__main__":
    name = sys.argv[1]
    bend, rest = bend_from_args(sys.argv[2:])
    bore = float(rest[0]) if rest and rest[0] != "air" else 0.0
    print(json.dumps(build(name, bend, bore, air="air" in rest), indent=1))
