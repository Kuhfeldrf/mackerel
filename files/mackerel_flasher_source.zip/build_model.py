"""Build the two printable halves of the chub-mackerel throw flasher."""
import json
import numpy as np
import triangle as tr
import trimesh
import manifold3d as m3d
import mackerel_geom as G

OUT = "out"


def top_surface_mesh(poly, max_area=0.18):
    ring = np.asarray(poly.exterior.coords)[:-1]
    n = len(ring)
    seg = np.c_[np.arange(n), (np.arange(n) + 1) % n]
    T = tr.triangulate(dict(vertices=ring, segments=seg), f"pq30a{max_area}")
    V2, F = T["vertices"], T["triangles"]
    # make all triangles CCW (normal +z)
    p = V2[F]
    area = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[area < 0] = F[area < 0][:, ::-1]
    return V2, F


def solid_from_heightfield(V2, F, z):
    n = len(V2)
    top = np.c_[V2, z]
    bot = np.c_[V2, np.zeros(n)]
    verts = np.r_[top, bot]
    faces = [F, F[:, ::-1] + n]
    # boundary edges = directed edges of the top that have no twin
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    bnd = np.array([k for k in e if (k[1], k[0]) not in key])
    i, j = bnd[:, 0], bnd[:, 1]
    walls = np.r_[np.c_[j, i, i + n], np.c_[j, i + n, j + n]]
    faces.append(walls)
    faces = np.vstack(faces)
    mesh = m3d.Mesh(vert_properties=verts.astype(np.float32), tri_verts=faces.astype(np.uint32))
    M = m3d.Manifold(mesh)
    assert M.status() == m3d.Error.NoError, M.status()
    return M


def stadium(L, H, depth, x, y):
    r = H / 2
    core = m3d.Manifold.cube([L - H, H, depth + 1]).translate([-(L - H) / 2, -r, -1])
    c1 = m3d.Manifold.cylinder(depth + 1, r, r, 64).translate([-(L - H) / 2, 0, -1])
    c2 = m3d.Manifold.cylinder(depth + 1, r, r, 64).translate([(L - H) / 2, 0, -1])
    return (core + c1 + c2).translate([x, y, 0])


def min_surface_over(x0, x1, y0, y1, step=0.4):
    xx, yy = np.meshgrid(np.arange(x0, x1, step), np.arange(y0, y1, step))
    z = G.surface_z(xx.ravel(), yy.ravel(), details=False)
    return float(z.min())


def build():
    poly = G.outline()
    V2, F = top_surface_mesh(poly)
    z = G.surface_z(V2[:, 0], V2[:, 1])
    half = solid_from_heightfield(V2, F, z)
    info = dict(FL=G.FL, total_length=round(poly.bounds[2] - poly.bounds[0], 1),
                height_with_fins=round(poly.bounds[3] - poly.bounds[1], 1),
                side_area_mm2=round(poly.area, 0), top_vertices=len(V2))

    cuts = []
    # wire channel along y=0 from snout tip to tail fork (half-round in each half)
    wr = (G.WIRE_D + 0.4) / 2
    wire = m3d.Manifold.cylinder(G.FL + 4, wr, wr, 24).rotate([0, 90, 0]).translate([-2, 0, 0])
    cuts.append(wire)

    # ballast chambers
    chambers = []
    for c in G.ballast_chambers(poly):
        zmin = min_surface_over(c["x"] - c["L"] / 2 - 1, c["x"] + c["L"] / 2 + 1,
                                c["y"] - c["H"] / 2 - 1, c["y"] + c["H"] / 2 + 1)
        depth = round(min(zmin - G.WALL, 6.5), 2)
        cuts.append(stadium(c["L"], c["H"], depth, c["x"], c["y"]))
        area = (c["L"] - c["H"]) * c["H"] + np.pi * (c["H"] / 2) ** 2
        chambers.append(dict(name=c["name"], x_center=round(c["x"], 1), depth_per_half=depth,
                             volume_both_halves_cc=round(2 * area * depth / 1000, 2)))
    info["chambers"] = chambers

    # alignment pin holes
    pins = []
    for (px, py) in G.pin_sites():
        zloc = min_surface_over(px - 1.5, px + 1.5, py - 1.5, py + 1.5, 0.3)
        depth = min(4.0, zloc - 1.2)
        if depth < 2.0:
            continue
        r = (G.PIN_D + 0.2) / 2
        cuts.append(m3d.Manifold.cylinder(depth + 1, r, r, 24).translate([px, py, -1]))
        pins.append(dict(x=round(px, 1), y=round(py, 1), depth=round(depth, 2)))
    info["pins"] = pins

    half = half - m3d.Manifold.batch_boolean(cuts, m3d.OpType.Add)
    assert half.status() == m3d.Error.NoError

    mm = half.to_mesh()
    left = trimesh.Trimesh(np.asarray(mm.vert_properties)[:, :3], np.asarray(mm.tri_verts), process=True)
    right = left.copy()
    right.apply_transform(trimesh.transformations.reflection_matrix([0, 0, 0], [1, 0, 0]))
    right.apply_translation([-right.bounds[0][0], 0, 0])

    left.export(f"{OUT}/mackerel_flasher_LEFT_half.stl")
    right.export(f"{OUT}/mackerel_flasher_RIGHT_half.stl")
    info["half_volume_cc"] = round(left.volume / 1000, 2)
    info["watertight"] = bool(left.is_watertight and right.is_watertight)
    info["half_bbox_mm"] = [round(v, 1) for v in (left.extents)]
    json.dump(info, open(f"{OUT}/model_info.json", "w"), indent=1)
    return info, left


if __name__ == "__main__":
    info, _ = build()
    print(json.dumps(info, indent=1))
