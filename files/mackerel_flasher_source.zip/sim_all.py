"""
Run the v2 sink simulation (with circulation lift) for every ballast combination
of all three designs and write out/web/sink_data.json for the viewer.
usage: python3 sim_all.py WOUNDED_BEND WOUNDED_KICK
"""
import base64, itertools, json, sys
import numpy as np
from multiprocessing import Pool
import sim2
import wounded as W
import build_curled as BC
import cavities as CV

web = json.load(open("out/web/meta.json"))
_wi = json.load(open("out/wounded_info.json"))
WB, WK = (float(sys.argv[1]), float(sys.argv[2])) if len(sys.argv) > 2 and sys.argv[1][0].isdigit() else (_wi["bend_deg"], _wi["kick_deg"])


def design_chambers(design):
    if design in CAVITY_DESIGNS:
        return [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind=c["kind"]) for c in CV.cavities()]
    out = []
    for c in web[design]["chambers"]:
        ctr = [c["x"], c["y"], 0.0] if design == "straight" else [c["x"], -c["depth"] / 2, 0.0]
        out.append(dict(name=c["name"], centre=ctr, cc=c["cc"], kind="ballast"))
    return out


def design_bend(design):
    if design == "scurve":
        return W.BendSegments(W.S_SEGMENTS)
    return {"straight": None, "curled": BC.bend, "wounded": W.Bend(WB, WK)}[design]


def solid_cc(design):
    if design in CAVITY_DESIGNS:
        return json.load(open(f"out/{design}_info.json"))["solid_cc"]
    return web[design]["solid_cc"]


CHARGES = [25, 30, 36, 40, 50]      # grams of tungsten putty in the head cavity
DEFAULT_CHARGE = 36
CHARGES_BY = {"wounded": CHARGES, "scurve": [15, 20, 25, 30, 36]}
DEFAULT_BY = {"wounded": DEFAULT_CHARGE, "scurve": 25}
CAVITY_DESIGNS = ("wounded", "scurve")


def job(a):
    design, fills = a
    if design in CAVITY_DESIGNS:
        ch = {c["name"]: c for c in design_chambers(design)}
        fd, parts = {}, []
        for k in fills:
            if k.startswith("HEAD@"):
                g = int(k.split("@")[1]); fd["HEAD"] = g / (ch["HEAD"]["cc"] * 10); parts.append(k)
            else:
                fd[k] = 1.0; parts.append(k)
        P = sim2.build_model(design_bend(design), design_chambers(design), fd, solid_cc=solid_cc(design))
        key = "+".join(sorted(parts))
    else:
        P = sim2.build_model(design_bend(design), design_chambers(design), set(fills), solid_cc=solid_cc(design))
        key = "+".join(sorted(fills))
    fr = sim2.run(P)
    m = sim2.metrics(fr, P)
    m["design"] = design; m["fills"] = key or "none"
    return design, key, fr.astype(np.float32), m


def jobs():
    out = []
    for d in CAVITY_DESIGNS:
        for g in CHARGES_BY[d]:
            for gut in (False, True):
                out.append((d, tuple(["HEAD@%d" % g] + (["GUT"] if gut else []))))
    for design in ("curled", "straight"):
        names = [c["name"] for c in design_chambers(design) if c["kind"] == "ballast"]
        for k in range(len(names) + 1):
            for combo in itertools.combinations(names, k):
                out.append((design, tuple(sorted(combo))))
    return out


if __name__ == "__main__":
    J = jobs()
    data = dict(hz=sim2.OUT_HZ, model=dict(Cd=sim2.CD, Cf=sim2.CF, KL=sim2.KL, dt=sim2.DT), runs={})
    only = [a[:-5] for a in sys.argv if a.endswith("-only")]
    if only:
        J = [j for j in J if j[0] in only]
        old = json.load(open("out/web/sink_data.json"))
        data["runs"] = {k: v for k, v in old["runs"].items() if k.split(":")[0] not in only}
    print(len(J), "runs", flush=True)
    with Pool(2) as pool:
        for design, key, fr, m in pool.imap_unordered(job, J):
            data["runs"][f"{design}:{key}"] = dict(n=len(fr), rg=m["rg_mm"], summary=m, b64=base64.b64encode(fr.tobytes()).decode())
            print(design, key, {k: m[k] for k in ("net_g", "t10", "sink", "head_down", "head_down_osc", "roll", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    json.dump(data, open("out/web/sink_data.json", "w"))
    print("ALL_DONE", flush=True)
