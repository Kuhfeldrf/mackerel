"""
Build sim3 strip-model bodies for the mackerel designs and run/score sink tests.
Body frame = the fish's own (flat-then-bent) frame, origin at the centre of mass.
"""
import json
import numpy as np
from shapely.geometry import LineString
import mackerel_geom as G
import sim2, sim3
import wounded as W
import build_curled as BC
import cavities as CV

FL = G.FL
POLY = G.outline()
web = json.load(open("out/web/meta.json"))
N_STRIPS = 56
X_END = 1.085 * FL


def section(x):
    """chord (y extent incl. fins), centre y, thickness, perimeter at flat x (mm)."""
    ln = LineString([(x, -100), (x, 100)])
    seg = POLY.intersection(ln)
    if seg.is_empty:
        return None
    ys = np.array([c[1] for g in getattr(seg, "geoms", [seg]) for c in g.coords])
    ymin, ymax = ys.min(), ys.max()
    yy = np.linspace(ymin, ymax, 80)
    z = G.surface_z(np.full_like(yy, x), yy, details=False)
    w = 2 * z.max()
    c = ymax - ymin
    return c, (ymin + ymax) / 2, w, 2 * (c + w)


def bend_for(design):
    if design == "straight":
        return None
    if design == "curled":
        return BC.bend
    if design == "wounded":
        info = json.load(open("out/wounded_info.json"))
        return W.Bend(info["bend_deg"], info["kick_deg"])
    if design == "scurve":
        return W.BendSegments(W.S_SEGMENTS)
    raise ValueError(design)


def theta_at(bend, x):
    if bend is None:
        return np.zeros_like(x)
    if bend is BC.bend:
        return np.interp(x, BC._xs, BC._theta)
    return np.interp(x, W.XS, bend.th)


def chambers_for(design):
    if design in ("wounded", "scurve"):
        return [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind=c["kind"]) for c in CV.cavities()]
    out = []
    for c in web[design]["chambers"]:
        ctr = [c["x"], c["y"], 0.0] if design == "straight" else [c["x"], -c["depth"] / 2, 0.0]
        out.append(dict(name=c["name"], centre=ctr, cc=c["cc"], kind="ballast"))
    return out


def solid_cc(design):
    if design in ("wounded", "scurve"):
        return json.load(open(f"out/{design}_info.json"))["solid_cc"]
    return web[design]["solid_cc"]


_STRIP_CACHE = {}


def flat_strips():
    if "s" not in _STRIP_CACHE:
        xs = np.linspace(0, X_END, N_STRIPS + 1)
        xm = (xs[1:] + xs[:-1]) / 2
        rows = []
        for x in xm:
            s = section(x)
            rows.append((x,) + (s if s else (0.5, 0.0, 0.5, 2.0)))
        _STRIP_CACHE["s"] = (np.array(rows), xs[1] - xs[0])
    return _STRIP_CACHE["s"]


def make_body(design, fills, coef=None, coat_g=6.0, putty_dx=0.0, extra=None, bend=None):
    """fills: set of chamber names (tungsten) or dict name -> tungsten fraction."""
    bend = bend_for(design) if bend is None else bend
    ch = chambers_for(design)
    if putty_dx:
        ch = [dict(c, centre=[c["centre"][0] + (putty_dx if c["name"] == "HEAD" else 0)] + list(c["centre"][1:])) for c in ch]
    P = sim2.build_model(bend, ch, fills, solid_cc=solid_cc(design), extra=extra)
    # optional coat-mass change (P assumed 6 g)
    m = P["m"] + (coat_g - 6.0) * 1e-3
    E, ev, rg = P["E"], P["I"], P["rg"]
    I_full = E @ np.diag(ev) @ E.T
    r_cb = E @ P["cb_b"]
    S, ds = flat_strips()
    x, c, yc, w, per = S[:, 0], S[:, 1], S[:, 2], S[:, 3], S[:, 4]
    pos = np.c_[x, yc, np.zeros_like(x)]
    if bend is not None:
        pos = bend(pos)
    th = theta_at(bend, x) if not hasattr(bend, "th") else np.interp(x, W.XS, bend.th)
    t = np.c_[np.cos(th), np.zeros_like(th), np.sin(th)]
    b = np.c_[-np.sin(th), np.zeros_like(th), np.cos(th)]
    a = np.tile([0.0, 1.0, 0.0], (len(x), 1))
    strips = dict(r=pos * 1e-3 - rg, t=t, a=a, b=b, ds=np.full(len(x), ds * 1e-3), c=c * 1e-3, w=w * 1e-3, per=per * 1e-3)
    tail = np.nonzero(x > 0.95 * FL)[0]
    te = int(tail[np.argmax(c[tail])])
    body_c = c[(x > 0.1 * FL) & (x < 0.6 * FL)].max()
    A_front = np.pi / 4 * w.max() * 1e-3 * body_c * 1e-3 * 0.8
    body = sim3.Body(m, I_full, r_cb, P["V_disp"], strips, te=te, te_span=c[te] * 1e-3, nose=0, A_front=A_front, coef=coef)
    body.meta = dict(rg_mm=(rg * 1000).round(2).tolist(), net_g=round((m - sim3.RHO_W * P["V_disp"]) * 1000, 1),
                     dry_g=round(m * 1000, 1))
    return body


R_START = sim2.R_START          # tossed in near-flat, rolled 35 deg, yawed 20 deg


def run(body, t_max=40.0, dt=0.003, hz=20, R0=None, v0=(0.7, -0.25, 0.15), w0=(0.6, 0.3, 0.9), depth_stop=10.5):
    R0 = R_START if R0 is None else R0
    s0 = np.r_[[0, -0.06, 0], sim3.mat2q(R0), R0.T @ np.asarray(v0), R0.T @ np.asarray(w0)]
    fr = sim3.integrate(body, s0, dt, t_max, hz, stop=lambda s: -s[1] > depth_stop)
    return fr[:, :7]


def metrics(fr, body, hz=20):
    depth = -fr[:, 1]
    tt = np.arange(len(fr)) / hz
    t10 = float(np.interp(10.0, depth, tt)) if depth.max() >= 10 else None
    late = slice(int(4 * hz), len(fr))
    Rs = np.array([sim3.qrot(q) for q in fr[late, 3:]])
    snout = -Rs[:, :, 0]
    head_down = np.degrees(np.arcsin(np.clip(-snout[:, 1], -1, 1)))
    flank = Rs[:, :, 2]
    roll = np.degrees(np.arccos(np.clip(np.abs(flank[:, 1]), 0, 1)))
    yaw = np.unwrap(np.arctan2(snout[:, 2], snout[:, 0]))
    yaw_rate = float(np.degrees(np.polyfit(tt[late], yaw, 1)[0])) if len(yaw) > 5 else 0.0
    xz = fr[late][:, [0, 2]]
    sway = float(np.sqrt(((xz - xz.mean(0)) ** 2).sum(1).mean())) if len(xz) else 0.0
    spd = np.diff(depth[late]) * hz
    return dict(net_g=body.meta["net_g"], dry_g=body.meta["dry_g"], t10=None if t10 is None else round(t10, 1),
                sink=round(float(spd.mean()), 3) if len(spd) else 0.0, sink_osc=round(float(spd.std()), 3) if len(spd) else 0.0,
                head_down=round(float(head_down.mean()), 1), head_down_osc=round(float(head_down.std()), 1),
                roll=round(float(roll.mean()), 1), roll_osc=round(float(roll.std()), 1),
                yaw_rate=round(yaw_rate, 1), sway_m=round(sway, 3), rg_mm=body.meta["rg_mm"])


def target_score(m):
    """How well a run matches 'slow head-first spiral with a light flutter'. Returns (ok, details)."""
    rock = 1.4 * max(m["roll_osc"], m["head_down_osc"])         # ~amplitude in degrees
    turn = abs(m["yaw_rate"])
    checks = dict(
        head_first=m["head_down"] >= 20,
        slow=0.15 <= m["sink"] <= 0.45,
        light_flutter=4 <= rock <= 25,
        spiral=20 <= turn <= 200 and m["sway_m"] <= 0.6,
    )
    return all(checks.values()), checks
