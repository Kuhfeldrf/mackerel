"""
Build the printable halves of the 'wounded bait' variant:
head + gut ballast, gentle body bend and tail kick (see wounded.py).
Split on the frontal plane (y = 0) into BACK and BELLY halves that print flat.
usage: python3 build_wounded.py BEND_DEG KICK_DEG
"""
import json, sys
import numpy as np
import trimesh
import manifold3d as m3d
import mackerel_geom as G
import build_curled as BC
import wounded as W
import cavities as CV

OUT = "out"
FL = G.FL


def stadium_y(c):
    """Pocket solid in flat coords: stadium in x-z (length L, radius r), y from y0 to y1."""
    L, r, h = c["L"], c["r"], c["y1"] - c["y0"]
    core = m3d.Manifold.cube([max(L - 2 * r, 0.01), 2 * r, h + 0.02]).translate([-(L - 2 * r) / 2, -r, -0.01])
    c1 = m3d.Manifold.cylinder(h + 0.02, r, r, 48).translate([-(L - 2 * r) / 2, 0, -0.01])
    c2 = m3d.Manifold.cylinder(h + 0.02, r, r, 48).translate([(L - 2 * r) / 2, 0, -0.01])
    s = core + c1 + c2                                    # extruded along +z, x-y profile
    s = s.rotate([-90, 0, 0])                             # z -> y : profile now in x-z, extrusion along +y
    return s.translate([c["x"], c["y0"], 0])


def build(bend_deg, kick_deg):
    bend = W.Bend(bend_deg, kick_deg)
    poly, V2, F, z, t = BC.skin()
    body, _, _ = BC.full_body(V2, F, z)
    cuts = []
    wr = (G.WIRE_D + 0.4) / 2
    cuts.append(m3d.Manifold.cylinder(FL + 4, wr, wr, 24).rotate([0, 90, 0]).translate([-2, 0, 0]))
    cavs = CV.cavities()
    for c in cavs:
        cuts.append(CV.manifold_of(c))
    chambers = [dict(name=c["name"], kind=c["kind"], cc=c["cc"], centre=c["centre"], x0=c["x0"], x1=c["x1"], band=c["band"]) for c in cavs]
    pins = []
    for px in (0.345 * FL, 0.725 * FL, 0.78 * FL):
        Wd = BC.zbody_at(px, -4.0)[0]
        pz = round(0.5 * Wd, 1)
        if Wd - pz - (G.PIN_D + 0.2) / 2 < 1.0:
            continue
        r = (G.PIN_D + 0.2) / 2
        for sgn in (1, -1):
            cuts.append(m3d.Manifold.cylinder(8.0, r, r, 24).rotate([90, 0, 0]).translate([px, 4.0, sgn * pz]))
        pins.append(dict(x=round(px, 1), z=pz))
    body = body - m3d.Manifold.batch_boolean(cuts, m3d.OpType.Add)
    body = body.refine_to_length(0.8)
    bent = body.warp_batch(lambda P: bend(P))
    assert bent.status() == m3d.Error.NoError
    back, belly = bent.split_by_plane([0, 1, 0], 0.0)

    def tm(M):
        mm = M.to_mesh()
        return trimesh.Trimesh(np.asarray(mm.vert_properties)[:, :3], np.asarray(mm.tri_verts), process=True)

    D, Vt, whole = tm(back), tm(belly), tm(bent)
    rot = trimesh.transformations.rotation_matrix
    D.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    Vt.apply_transform(rot(-np.pi / 2, [1, 0, 0]))
    for m in (D, Vt):
        m.apply_translation(-m.bounds[0])
    D.export(f"{OUT}/wounded_mackerel_BACK_half.stl")
    Vt.export(f"{OUT}/wounded_mackerel_BELLY_half.stl")
    info = dict(bend_deg=bend_deg, kick_deg=kick_deg, engrave_mm=BC.ENGRAVE, chambers=chambers, pins=pins,
                back=dict(volume_cc=round(D.volume / 1000, 2), bbox=D.extents.round(1).tolist(), watertight=bool(D.is_watertight)),
                belly=dict(volume_cc=round(Vt.volume / 1000, 2), bbox=Vt.extents.round(1).tolist(), watertight=bool(Vt.is_watertight)),
                whole_bbox=whole.extents.round(1).tolist(),
                solid_cc=round((D.volume + Vt.volume) / 1000, 2))
    json.dump(info, open(f"{OUT}/wounded_info.json", "w"), indent=1)
    # theta table for the web viewer (same grid as the JS bend)
    np.save(f"{OUT}/web/wounded_theta.npy", bend.th.astype(np.float32))
    return info


if __name__ == "__main__":
    print(json.dumps(build(float(sys.argv[1]), float(sys.argv[2])), indent=1))
