"""
Sink simulator v3: slender-body strip model.

The body is cut into thin slices (strips) along its centre line. Each strip is
treated as a 2D section of chord c (fish height, dorsal-ventral) and thickness w,
using the quasi-steady falling-plate model of Andersen, Pesavento & Wang
(J. Fluid Mech. 2005), calibrated on their aluminium-plate experiments:

  * cross-flow drag     C_D(a) = CD0 cos^2 a + CD90 sin^2 a
  * circulation lift    translational  rho*CT*c*|u_a u_b|   (perpendicular to the flow)
                        rotational     rho*CR/2*c^2*(w_t x u)   (Magnus-like)
  * added mass          (pi/4) rho c^2 normal to the chord, (pi/4) rho w^2 along it,
                        (pi/128) rho (c^2-w^2)^2 about the strip axis
  * rotational drag     about the strip axis
Along the body: skin friction, nose/base form drag, and Lighthill's reactive
(trailing-edge) force at the tail fin when water flows from head to tail.
All strip added masses are assembled into one 6x6 matrix, so Kirchhoff's
equations give the correct Munk moments for straight, kicked and curved bodies.
"""
import json
import numpy as np
from simulate_sink import qmul, qrot, mat2q, rot, R_REST

RHO_W, GRAV = 1025.0, 9.81

COEF = dict(CT=1.0, CR=1.1, CD0=0.2, CD90=2.0, Ca=1.0, Crot=1.0, Cf=0.010, Cnose=0.2, KTE=1.0)


def skew(v):
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


class Body:
    """m (kg), I (3x3 about CG, kg m^2), r_cb (CB minus CG, m), V (m^3),
    strips: dict of arrays (r, t, a, b, ds, c, w, per) in metres, body frame about CG.
    te: index of the trailing-edge strip (tail fin) or None; nose: index or None; A_front (m^2)."""

    def __init__(self, m, I, r_cb, V, strips, te=None, te_span=0.0, nose=None, A_front=0.0, coef=None):
        self.m, self.I, self.r_cb, self.V = m, np.asarray(I, float), np.asarray(r_cb, float), V
        self.S = {k: np.asarray(v, float) for k, v in strips.items()}
        self.te, self.te_span, self.nose, self.A_front = te, te_span, nose, A_front
        self.set_coef(coef or COEF)

    def set_coef(self, coef):
        self.C = dict(COEF); self.C.update(coef)
        S, C = self.S, self.C
        r, t, a, b, ds, c, w = S["r"], S["t"], S["a"], S["b"], S["ds"], S["c"], S["w"]
        mb = C["Ca"] * np.pi / 4 * RHO_W * c ** 2 * ds
        ma = C["Ca"] * np.pi / 4 * RHO_W * w ** 2 * ds
        Ir = C["Ca"] * np.pi / 128 * RHO_W * np.maximum(c ** 2 - w ** 2, 0) ** 2 * ds
        Jb = np.c_[b, np.cross(r, b)]
        Ja = np.c_[a, np.cross(r, a)]
        Jr = np.c_[np.zeros_like(t), t]
        MA = (np.einsum("i,ij,ik->jk", mb, Jb, Jb) + np.einsum("i,ij,ik->jk", ma, Ja, Ja)
              + np.einsum("i,ij,ik->jk", Ir, Jr, Jr))
        M = np.zeros((6, 6))
        M[:3, :3] = self.m * np.eye(3)
        M[3:, 3:] = self.I
        self.M = M + MA
        self.Minv = np.linalg.inv(self.M)
        self.MA = MA

    def forces(self, v, w, g_b):
        S, C = self.S, self.C
        r, t, a, b, ds, c, wd, per = S["r"], S["t"], S["a"], S["b"], S["ds"], S["c"], S["w"], S["per"]
        F = self.m * g_b - RHO_W * self.V * g_b
        T = np.cross(self.r_cb, -RHO_W * self.V * g_b)
        u = v + np.cross(w, r)
        ua = np.einsum("ij,ij->i", u, a); ub = np.einsum("ij,ij->i", u, b); ut = np.einsum("ij,ij->i", u, t)
        wt = t @ w
        U = np.sqrt(ua * ua + ub * ub) + 1e-12
        uc = ua[:, None] * a + ub[:, None] * b
        # cross-flow drag
        cd = C["CD0"] * (ua / U) ** 2 + C["CD90"] * (ub / U) ** 2
        Fs = -(0.5 * RHO_W * c * ds * cd * U)[:, None] * uc
        # translational circulation lift: perpendicular to the cross-flow, opposing the normal component
        uh = uc / U[:, None]
        nperp = b - (ub / U)[:, None] * uh
        npm = np.linalg.norm(nperp, axis=1) + 1e-12
        mag = RHO_W * C["CT"] * c * ds * np.abs(ua * ub) / U * U
        Fs += (-np.sign(ub) * mag / npm)[:, None] * nperp
        # rotational (Magnus-like) lift
        Fs += (0.5 * RHO_W * C["CR"] * c ** 2 * ds * wt)[:, None] * np.cross(t, uc)
        # axial skin friction
        Fs += -(0.5 * RHO_W * C["Cf"] * per * ds * np.abs(ut) * ut)[:, None] * t
        # rotational drag about each strip axis
        Tr = -(0.5 * RHO_W * C["Crot"] * C["CD90"] * c ** 4 / 32 * ds * np.abs(wt) * wt)[:, None] * t
        F = F + Fs.sum(0)
        T = T + np.cross(r, Fs).sum(0) + Tr.sum(0)
        # nose / base form drag
        if self.nose is not None and self.A_front > 0:
            i = self.nose
            f = -0.5 * RHO_W * C["Cnose"] * self.A_front * abs(ut[i]) * ut[i] * t[i]
            F = F + f; T = T + np.cross(r[i], f)
        # Lighthill reactive force at the tail fin trailing edge (flow head -> tail, i.e. ut < 0)
        if self.te is not None and ut[self.te] < 0:
            i = self.te
            f = -C["KTE"] * np.pi / 4 * RHO_W * self.te_span ** 2 * abs(ut[i]) * ub[i] * b[i]
            F = F + f; T = T + np.cross(r[i], f)
        return F, T

    def deriv(self, s):
        q, v, w = s[3:7], s[7:10], s[10:13]
        R = qrot(q)
        g_b = R.T @ np.array([0, -GRAV, 0])
        F, T = self.forces(v, w, g_b)
        P = self.M @ np.r_[v, w]
        p, L = P[:3], P[3:]
        rhs = np.r_[F - np.cross(w, p), T - np.cross(w, L) - np.cross(v, p)]
        return np.r_[R @ v, 0.5 * qmul(q, np.r_[0, w]), self.Minv @ rhs]


def integrate(body, s0, dt, t_max, out_hz, stop=None):
    s, t, frames, nxt = s0.copy(), 0.0, [], 0.0
    while t <= t_max + 1e-9:
        if t >= nxt - 1e-9:
            frames.append(s.copy()); nxt += 1.0 / out_hz
            if stop is not None and stop(s):
                break
        k1 = body.deriv(s); k2 = body.deriv(s + dt / 2 * k1); k3 = body.deriv(s + dt / 2 * k2); k4 = body.deriv(s + dt * k3)
        s = s + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        s[3:7] /= np.linalg.norm(s[3:7]); t += dt
        if not np.all(np.isfinite(s)):
            raise RuntimeError(f"diverged at t={t:.3f}")
    return np.array(frames)
