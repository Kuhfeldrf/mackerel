"""
'Wounded bait' variant: head + gut ballast, a gentle body bend and an optional
tail kick (all lateral bending, so the back/belly split plane stays flat for printing).

Bend law shared with the web viewer: theta(x) is tabulated on a fixed grid
(BX0..BX1, NS points) and positions are integrated with midpoint angles.
"""
import numpy as np
import mackerel_geom as G

FL = G.FL
NS, BX0, BX1 = 2400, -12.0, 1.14 * FL
XS = np.linspace(BX0, BX1, NS)


def _ss(a, b, v):
    s = np.clip((v - a) / (b - a), 0, 1)
    return s * s * (3 - 2 * s)


def _bump(a, b, ramp):
    w = _ss(a * FL, (a + ramp) * FL, XS) * (1 - _ss((b - ramp) * FL, b * FL, XS))
    return w / np.trapezoid(w, XS)


def theta_table(bend_deg, kick_deg, bend_span=(0.30, 0.66), kick_span=(0.83, 0.94)):
    k = (np.radians(bend_deg) * _bump(*bend_span, 0.10)
         + np.radians(kick_deg) * _bump(*kick_span, 0.04))
    th = -np.concatenate([[0], np.cumsum((k[1:] + k[:-1]) / 2 * np.diff(XS))])
    return th


class Bend:
    def __init__(self, bend_deg, kick_deg):
        self.bend_deg, self.kick_deg = bend_deg, kick_deg
        th = theta_table(bend_deg, kick_deg)
        tm = (th[1:] + th[:-1]) / 2
        dx = np.diff(XS)
        cx = np.concatenate([[BX0], BX0 + np.cumsum(np.cos(tm) * dx)])
        cz = np.concatenate([[0], np.cumsum(np.sin(tm) * dx)])
        cx -= np.interp(0, XS, cx); cz -= np.interp(0, XS, cz)
        self.th, self.cx, self.cz = th, cx, cz

    def __call__(self, P):
        P = np.asarray(P, float)
        x, y, z = P[:, 0], P[:, 1], P[:, 2]
        th = np.interp(x, XS, self.th)
        return np.c_[np.interp(x, XS, self.cx) - z * np.sin(th), y, np.interp(x, XS, self.cz) + z * np.cos(th)]


# ballast chambers for this variant (flat-frame x position, chamber length) -- all in the belly half
# (name, x centre, length, kind): "ballast" = tungsten putty or epoxy, "air" = sealed void
CHAMBERS = [("HEAD", 0.115 * FL, 0.130 * FL, "ballast"), ("GUT", 0.270 * FL, 0.090 * FL, "ballast"),
            ("FLOAT1", 0.455 * FL, 0.140 * FL, "air"), ("FLOAT2", 0.610 * FL, 0.110 * FL, "air")]
