"""Head-charge sweep for the S-curve body."""
import json
from multiprocessing import Pool
import sim2, wounded as W, cavities as CV

SOLID = json.load(open("out/scurve_info.json"))["solid_cc"]
CH = [dict(name=c["name"], centre=c["centre"], cc=c["cc"], kind=c["kind"]) for c in CV.cavities()]
HEAD_CC = [c["cc"] for c in CH if c["name"] == "HEAD"][0]


def job(g):
    P = sim2.build_model(W.BendSegments(W.S_SEGMENTS), CH, {"HEAD": g / (HEAD_CC * 10)}, solid_cc=SOLID)
    fr = sim2.run(P)
    return g, sim2.metrics(fr, P)


if __name__ == "__main__":
    with Pool(2) as p:
        res = p.map(job, [15, 25, 36, 45])
    for g, m in res:
        print(g, {k: m[k] for k in ("net_g", "t10", "sink", "head_down", "head_down_osc", "roll", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    print("SWEEP_S_DONE")
