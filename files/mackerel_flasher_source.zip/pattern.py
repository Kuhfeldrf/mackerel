"""
Pacific chub mackerel colour pattern, defined on the fish surface in (x, t)
where t = -1 belly midline ... +1 dorsal midline.

Field marks (FAO / FishBase, Scomber japonicus):
  * back steel blue-green crossed by narrow, zig-zag / undulating dark oblique lines
  * lower sides and belly silvery, faintly yellow; belly UNMARKED in the Pacific
  * two well-separated dorsal fins, 5 dorsal + 5 anal finlets, deeply forked tail
Returns RGB colour + alpha "ink" (alpha 0 = clear decal film = chrome shows through).
"""
import numpy as np
from scipy.ndimage import gaussian_filter, map_coordinates
import mackerel_geom as G

FL = G.FL
rng = np.random.default_rng(7)

# --- smooth noise fields on an (x, t) grid -----------------------------------
_NX, _NT = 1200, 300
_XR = (-5.0, 1.12 * FL)
_TR = (-1.6, 1.6)


def _field(sigma_x, sigma_t, seed):
    r = np.random.default_rng(seed).standard_normal((_NT, _NX))
    f = gaussian_filter(r, (sigma_t, sigma_x), mode="wrap")
    return f / f.std()


_N1 = _field(14, 12, 1)      # line meander
_N2 = _field(3, 3, 2)      # line width
_N3 = _field(10, 4, 3)     # line breaks
_N4 = _field(14, 50, 4)    # wavy edge of the dark back


def _sample(F, x, t):
    ix = (np.asarray(x) - _XR[0]) / (_XR[1] - _XR[0]) * (_NX - 1)
    it = (np.clip(t, *_TR) - _TR[0]) / (_TR[1] - _TR[0]) * (_NT - 1)
    return map_coordinates(F, [it, ix], order=1, mode="nearest")


def hexc(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])


def _ss(e0, e1, v):
    s = np.clip((v - e0) / (e1 - e0), 0, 1)
    return s * s * (3 - 2 * s)


def _over(rgb, a, c, ca):
    """composite colour c (alpha ca) over (rgb, a), both premultiplied-free."""
    ca = ca[..., None]
    out_a = ca[..., 0] + a * (1 - ca[..., 0])
    num = c * ca + rgb * (a[..., None] * (1 - ca))
    rgb2 = np.where(out_a[..., None] > 1e-6, num / np.maximum(out_a[..., None], 1e-6), rgb)
    return rgb2, out_a


DORSAL_DARK = hexc("#102833")
BACK_MID = hexc("#24606c")
BACK_IRID = hexc("#3f8f8a")
BAR = hexc("#0b161d")
GOLD = hexc("#d8c06a")
CHEEK = hexc("#c6a75c")
FIN_DUSK = hexc("#3a4950")
FINLET = hexc("#7c7546")
TAIL = hexc("#33414a")
PECT = hexc("#232d34")
PALE_FIN = hexc("#9aa4a8")


def colour(x, y, t, is_fin):
    """x, y in mm; t body coordinate (only meaningful where not is_fin)."""
    x = np.asarray(x, float); y = np.asarray(y, float); t = np.asarray(t, float)
    n = x.shape
    rgb = np.zeros(n + (3,))
    a = np.zeros(n)
    u = x / FL
    H = G.halfdepth_mm(x)
    body = ~is_fin

    # ---------------- back: gradient, wavy lower edge ----------------
    edge = -0.02 + 0.10 * _sample(_N4, x, t * 0 + 0.0) + 0.06 * np.sin(u * 37)
    back_w = _ss(edge - 0.10, edge + 0.18, t)
    grad = np.clip((t - edge) / (1 - edge + 1e-6), 0, 1)[..., None]
    back_c = BACK_IRID * (1 - grad) ** 1.5 + BACK_MID * (1 - (1 - grad) ** 1.5)
    back_c = back_c * (1 - grad ** 3) + DORSAL_DARK * grad ** 3
    back_a = back_w * (0.55 + 0.35 * grad[..., 0])
    rgb, a = _over(rgb, a, back_c, back_a * body)

    # ---------------- oblique zig-zag bars on the back ----------------
    spacing = 0.0185 * FL
    slant = 0.55
    tri = lambda v: 2 * np.abs(v - np.floor(v + 0.5))
    zig = 0.32 * (tri(t * H / (0.0095 * FL)) - 0.5)
    phi = (x + slant * (1 - t) * H + 0.0065 * FL * _sample(_N1, x, t)) / spacing + zig
    dist = np.abs(phi - np.round(phi)) * spacing
    w = 0.0042 * FL * (1 + 0.30 * _sample(_N2, x, t))
    bar = 1 - _ss(w * 0.35, w * 0.65, dist)
    bar *= _ss(-1.7, -1.0, _sample(_N3, x, t))                    # occasional breaks
    region = _ss(0.255 * FL, 0.30 * FL, x) * (1 - _ss(0.86 * FL, 0.90 * FL, x))
    bar *= region * _ss(edge + 0.05, edge + 0.30, t) * body
    rgb, a = _over(rgb, a, np.broadcast_to(BAR, rgb.shape), 0.88 * bar)

    # ---------------- head ----------------
    head = 1 - _ss(G.operc_x(np.clip(t, -1, 1)) - 1.0, G.operc_x(np.clip(t, -1, 1)) + 1.0, x)
    cap = head * _ss(0.30, 0.55, t) * body                          # dark top of head
    rgb, a = _over(rgb, a, np.broadcast_to(DORSAL_DARK, rgb.shape), 0.85 * cap)
    cheek = head * (1 - _ss(0.25, 0.45, t)) * _ss(-0.85, -0.5, t) * _ss(0.09 * FL, 0.14 * FL, x) * body
    rgb, a = _over(rgb, a, np.broadcast_to(CHEEK, rgb.shape), 0.30 * cheek)
    snout = (1 - _ss(0.02 * FL, 0.06 * FL, x)) * _ss(-0.2, 0.2, t) * body
    rgb, a = _over(rgb, a, np.broadcast_to(DORSAL_DARK, rgb.shape), 0.7 * snout)
    # thin dark edge on the gill cover
    d_op = np.abs(x - G.operc_x(np.clip(t, -1, 1)))
    opl = (1 - _ss(0.3, 0.9, d_op)) * _ss(-0.85, -0.6, t) * (1 - _ss(0.5, 0.8, t)) * body
    rgb, a = _over(rgb, a, np.broadcast_to(hexc("#3b4a4c"), rgb.shape), 0.45 * opl)

    # ---------------- faint brassy wash on the lower flank, clean belly ----------------
    low = _ss(-0.80, -0.45, t) * (1 - _ss(-0.10, 0.10, t)) * _ss(0.10 * FL, 0.20 * FL, x) \
        * (1 - _ss(0.80 * FL, 0.88 * FL, x)) * body
    rgb, a = _over(rgb, a, np.broadcast_to(GOLD, rgb.shape), 0.16 * low)

    # ---------------- lateral line (faint, follows the back) ----------------
    tl = 0.42 - 0.10 * u
    ll = (1 - _ss(0.15, 0.35, np.abs(t - tl) * H)) * _ss(0.27 * FL, 0.30 * FL, x) * (1 - _ss(0.84 * FL, 0.88 * FL, x)) * body
    rgb, a = _over(rgb, a, np.broadcast_to(hexc("#1d3842"), rgb.shape), 0.30 * ll)

    # ---------------- pectoral fin ----------------
    p0, p1 = G.pect_points()
    dp, sp = G._seg_dist(x, y, p0, p1)
    pect = 1 - _ss(-0.3, 0.4, dp - (3.6 - 2.6 * sp))
    rgb, a = _over(rgb, a, np.broadcast_to(PECT, rgb.shape), 0.72 * pect * body)

    # ---------------- fins ----------------
    tailfin = is_fin & (x > 0.87 * FL)
    finlet = is_fin & (x > 0.66 * FL) & ~tailfin
    dors = is_fin & (y > 0) & ~finlet & ~tailfin
    vent = is_fin & (y <= 0) & ~finlet & ~tailfin
    rgb, a = _over(rgb, a, np.broadcast_to(FIN_DUSK, rgb.shape), 0.62 * dors)
    rgb, a = _over(rgb, a, np.broadcast_to(FINLET, rgb.shape), 0.62 * finlet)
    rgb, a = _over(rgb, a, np.broadcast_to(PALE_FIN, rgb.shape), 0.35 * vent)
    tdark = 0.55 + 0.30 * _ss(0.95 * FL, 1.07 * FL, x)
    tail_zone = (tailfin | (body & (x > 0.86 * FL))) * _ss(0.875 * FL, 0.93 * FL, x)
    rgb, a = _over(rgb, a, np.broadcast_to(TAIL, rgb.shape), tdark * tail_zone)

    # eye: leave clear (3D eye goes on top) - transparent hole
    eye = np.hypot(x - G.EYE_X, y - G.EYE_Y) < G.EYE_D / 2 + 0.2
    a = np.where(eye, 0.0, a)
    return rgb, a


def bar_mask(x, t):
    """0..1 intensity of the dark back lines (same field as the decal) -- used to
    engrave them into the curled model as paint-wash grooves."""
    x = np.asarray(x, float); t = np.asarray(t, float)
    u = x / FL
    H = G.halfdepth_mm(x)
    edge = -0.02 + 0.10 * _sample(_N4, x, t * 0) + 0.06 * np.sin(u * 37)
    spacing = 0.0185 * FL
    tri = lambda v: 2 * np.abs(v - np.floor(v + 0.5))
    zig = 0.32 * (tri(t * H / (0.0095 * FL)) - 0.5)
    phi = (x + 0.55 * (1 - t) * H + 0.0065 * FL * _sample(_N1, x, t)) / spacing + zig
    dist = np.abs(phi - np.round(phi)) * spacing
    w = 0.0042 * FL * (1 + 0.30 * _sample(_N2, x, t))
    bar = 1 - _ss(w * 0.35, w * 0.65, dist)
    bar *= _ss(-1.7, -1.0, _sample(_N3, x, t))
    bar *= _ss(0.255 * FL, 0.30 * FL, x) * (1 - _ss(0.86 * FL, 0.90 * FL, x))
    bar *= _ss(edge + 0.05, edge + 0.30, t) * (np.abs(t) < 0.97)
    return bar
