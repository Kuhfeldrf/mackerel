"""
6-DOF sinking simulation of the mackerel flasher in still sea water.

Model (simplified, for visualisation -- pool-test the real thing):
  * rigid body: PETG shell (uniform) + chamber contents (epoxy or tungsten putty)
  * gravity at the centre of mass, buoyancy at the centre of volume
  * quasi-steady "Newtonian" facet drag: every surface facet whose normal faces
    into the relative flow gets pressure 0.5*rho*Cd*(u.n)^2, plus skin friction
  * added mass / added inertia from projected areas (disc formulas), including
    the Munk moment (-v x Ma v) that makes flat bodies flutter
Equations: Kirchhoff rigid body in principal axes about the CG, RK4.

Writes out/web/sink_data.json with a trajectory for every ballast combination.
"""
import itertools, json, sys
import numpy as np
import triangle as tr
import trimesh
from multiprocessing import Pool
import mackerel_geom as G
import build_curled as BC

RHO_W, GRAV = 1025.0, 9.81
CD, CF = 1.15, 0.008
DT, OUT_HZ, T_MAX, DEPTH_STOP = 0.003, 20, 40.0, 10.5
FL = G.FL

web = json.load(open("out/web/meta.json"))


# ------------------------------------------------------------------ geometry
def coarse_mesh(curled):
    poly = G.outline()
    ring = np.asarray(poly.exterior.coords)[:-1]
    n = len(ring)
    T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]), "pq28a5")
    V2, F = T["vertices"], T["triangles"]
    p = V2[F]
    ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[ar < 0] = F[ar < 0][:, ::-1]
    z = G.surface_z(V2[:, 0], V2[:, 1], details=False)
    nv = len(V2)
    V = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    b = np.array([k for k in e if (k[1], k[0]) not in key])
    Fa = np.vstack([F, F[:, ::-1] + nv, np.c_[b[:, 1], b[:, 0], b[:, 0] + nv], np.c_[b[:, 1], b[:, 0] + nv, b[:, 1] + nv]])
    if curled:
        V = BC.bend(V)
    m = trimesh.Trimesh(V * 1e-3, Fa, process=False)          # metres
    assert m.is_watertight, "sim mesh not watertight"
    return m


def chamber_centres(design):
    out = []
    for c in web[design]["chambers"]:
        if design == "straight":
            pt = np.array([[c["x"], c["y"], 0.0]])
        else:
            pt = BC.bend(np.array([[c["x"], -c["depth"] / 2, 0.0]]))
        out.append((c["name"], pt[0] * 1e-3, c["cc"] * 1e-6))
    return out


# ------------------------------------------------------------------ model
def build_model(design, fills):
    mesh = coarse_mesh(design == "curled")
    d = web[design]
    ch = chamber_centres(design)
    V_ch = sum(v for _, _, v in ch)
    V_mesh = mesh.volume
    m_shell = (1.27 * d["solid_cc"] * 0.97 + 6.0) * 1e-3          # kg
    rho_s = m_shell / (V_mesh - V_ch)
    mp = mesh.mass_properties
    c0 = np.asarray(mp["center_mass"])
    I0 = np.asarray(mp["inertia"]) * rho_s                      # about c0, unit density -> scale
    M = rho_s * V_mesh
    pts = [(M, c0)]
    for name, c, v in ch:
        fill = 10000.0 if name in fills else 1150.0
        pts.append((-rho_s * v, c))
        pts.append((fill * v, c))
    m = sum(w for w, _ in pts)
    rg = sum(w * c for w, c in pts) / m
    I = I0 + M * ((c0 - rg) @ (c0 - rg) * np.eye(3) - np.outer(c0 - rg, c0 - rg))
    for w, c in pts[1:]:
        r = c - rg
        I += w * (r @ r * np.eye(3) - np.outer(r, r))
    evals, E = np.linalg.eigh(I)
    if np.linalg.det(E) < 0:
        E[:, 2] *= -1
    V_disp = (d["solid_cc"] + sum(c["cc"] for c in d["chambers"])) * 1e-6
    cb = c0                                                      # centre of volume
    # facets in principal body frame
    fc = mesh.triangles_center
    fa = mesh.area_faces
    fn = mesh.face_normals
    Bc = (fc - rg) @ E
    Bn = fn @ E
    Aproj = np.array([0.5 * np.sum(np.abs(Bn[:, i]) * fa) for i in range(3)])
    Ma = 0.48 * RHO_W * Aproj ** 1.5
    Ia = np.array([0.356 * RHO_W * sum((Aproj[j] / np.pi) ** 2.5 for j in range(3) if j != i) for i in range(3)])
    return dict(m=m, I=evals, E=E, rg=rg, cb_b=(cb - rg) @ E, V_disp=V_disp, Bc=Bc, Bn=Bn, A=fa,
                Ma=Ma, Ia=Ia, net_g=(m - RHO_W * V_disp) * 1000, dry_g=m * 1000)


# ------------------------------------------------------------------ dynamics
def qmul(a, b):
    w1, x1, y1, z1 = a; w2, x2, y2, z2 = b
    return np.array([w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2, w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
                     w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2, w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2])


def qrot(q):
    w, x, y, z = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def mat2q(R):
    t = np.trace(R)
    if t > 0:
        s = 0.5 / np.sqrt(t + 1); return np.array([0.25 / s, (R[2, 1] - R[1, 2]) * s, (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s])
    i = np.argmax(np.diag(R))
    if i == 0:
        s = 2 * np.sqrt(1 + R[0, 0] - R[1, 1] - R[2, 2]); return np.array([(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s])
    if i == 1:
        s = 2 * np.sqrt(1 + R[1, 1] - R[0, 0] - R[2, 2]); return np.array([(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s])
    s = 2 * np.sqrt(1 + R[2, 2] - R[0, 0] - R[1, 1]); return np.array([(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s])


def deriv(s, P):
    p, q, v, w = s[:3], s[3:7], s[7:10], s[10:13]
    R = qrot(q)
    g_b = R.T @ np.array([0, -GRAV, 0])
    F = P["m"] * g_b
    Fb = -RHO_W * P["V_disp"] * g_b
    F = F + Fb
    Mo = np.cross(P["cb_b"], Fb)
    u = v + np.cross(w, P["Bc"])
    un = np.einsum("ij,ij->i", u, P["Bn"])
    front = np.maximum(un, 0)
    Fp = -(0.5 * RHO_W * CD * P["A"] * front ** 2)[:, None] * P["Bn"]
    ut = u - un[:, None] * P["Bn"]
    utm = np.linalg.norm(ut, axis=1)
    Ft = -(0.5 * RHO_W * CF * P["A"] * utm)[:, None] * ut
    Ff = Fp + Ft
    F = F + Ff.sum(0)
    Mo = Mo + np.cross(P["Bc"], Ff).sum(0)
    Mt = P["m"] + P["Ma"]
    It = P["I"] + P["Ia"]
    dv = (F - np.cross(w, Mt * v)) / Mt
    dw = (Mo - np.cross(w, It * w) - np.cross(v, P["Ma"] * v)) / It
    dp = R @ v
    dq = 0.5 * qmul(q, np.r_[0, w])
    return np.r_[dp, dq, dv, dw]


def rot(axis, deg):
    a = np.radians(deg); axis = np.asarray(axis, float) / np.linalg.norm(axis)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(a) * K + (1 - np.cos(a)) * K @ K


# rest attitude: fish lying on its side, left flank (+z) facing down
R_REST = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)
R_START = rot([1, 0, 0], 70) @ rot([0, 1, 0], 25) @ R_REST     # tossed in rolled 70 deg, yawed 25


def simulate(job):
    design, fills = job
    P = build_model(design, set(fills))
    R0 = R_START @ P["E"]
    v0 = R0.T @ np.array([0.7, -0.25, 0.15])
    w0 = R0.T @ np.array([0.9, 0.4, 1.4])
    s = np.r_[[0, -0.06, 0], mat2q(R0), v0, w0]
    t, frames, nxt = 0.0, [], 0.0
    while t <= T_MAX:
        if t >= nxt - 1e-9:
            Rf = qrot(s[3:7]) @ P["E"].T                    # fish frame -> world
            frames.append(np.r_[s[:3], mat2q(Rf)])
            nxt += 1.0 / OUT_HZ
            if -s[1] > DEPTH_STOP:
                break
        k1 = deriv(s, P); k2 = deriv(s + DT / 2 * k1, P); k3 = deriv(s + DT / 2 * k2, P); k4 = deriv(s + DT * k3, P)
        s = s + DT / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        s[3:7] /= np.linalg.norm(s[3:7])
        t += DT
        if not np.all(np.isfinite(s)):
            raise RuntimeError(f"diverged {design} {fills} at t={t}")
    fr = np.array(frames)
    # summary: time to 10 m, late sink speed, attitude of the flank normal (fish z) vs vertical
    depth = -fr[:, 1]
    tt = np.arange(len(fr)) / OUT_HZ
    t10 = float(np.interp(10.0, depth, tt)) if depth.max() >= 10 else None
    late = slice(max(0, len(fr) - 5 * OUT_HZ), len(fr))
    zw = np.array([qrot(q)[:, 2] for q in fr[late, 3:]])
    tilt = float(np.degrees(np.arccos(np.clip(-zw[:, 1], -1, 1))).mean())   # 0 = left flank down (U opening up)
    xw = np.array([qrot(q)[:, 0] for q in fr[late, 3:]])
    head_pitch = float(np.degrees(np.arcsin(np.clip(xw[:, 1], -1, 1))).mean())
    vz = np.diff(depth[late]) * OUT_HZ
    summ = dict(design=design, fills="+".join(fills) or "none", net_g=round(P["net_g"], 1), dry_g=round(P["dry_g"], 1),
                t10=None if t10 is None else round(t10, 1), late_speed=round(float(vz.mean()), 3),
                flank_down_tilt_deg=round(tilt, 1), head_pitch_deg=round(head_pitch, 1),
                rg_mm=(P["rg"] * 1000).round(2).tolist())
    return design, "+".join(sorted(fills)), fr.astype(np.float32), summ


def jobs():
    out = []
    for design in ("curled", "straight"):
        names = [c["name"] for c in web[design]["chambers"]]
        for k in range(len(names) + 1):
            for combo in itertools.combinations(names, k):
                out.append((design, tuple(sorted(combo))))
    return out


if __name__ == "__main__":
    J = jobs()
    if len(sys.argv) > 1 and sys.argv[1] == "one":
        _, _, fr, s = simulate(("curled", ("C",)))
        print(json.dumps(s, indent=1), len(fr)); sys.exit()
    with Pool(2) as pool:
        res = pool.map(simulate, J)
    import base64
    data = dict(hz=OUT_HZ, model=dict(Cd=CD, Cf=CF, dt=DT), runs={})
    for design, key, fr, s in res:
        data["runs"][f"{design}:{key}"] = dict(n=len(fr), rg=s["rg_mm"], summary=s,
                                               b64=base64.b64encode(fr.tobytes()).decode())
        print(s)
    json.dump(data, open("out/web/sink_data.json", "w"))
