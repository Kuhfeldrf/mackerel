"""Wrap the viewer page as a standalone index.html for GitHub Pages."""
import sys
body = open("out/web/chub_mackerel_flasher.html").read()
head = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="Interactive 3D viewer and sink simulation for a 3D-printable chub mackerel spearfishing throw flasher.">
<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style>
'''
te = body.index("</title>") + len("</title>")
rest = body[te:]
sp = rest.index("</style>") + len("</style>")
page = head + body[:te] + rest[:sp] + "\n</head>\n<body>\n" + rest[sp:] + "\n</body>\n</html>\n"
open(sys.argv[1], "w").write(page)
print("index.html KB", len(page) // 1024)
