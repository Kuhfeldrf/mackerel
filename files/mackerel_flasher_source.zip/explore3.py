"""Nominal-coefficient exploration of head-first designs with the strip model."""
import json, sys
from multiprocessing import Pool
import numpy as np
import fish3, wounded as W

HEAD_CC = 9.024


def variant(kind, p):
    if kind == "S":
        sc, kick = p["scale"], p.get("kick", 0.0)
        segs = [(95.0 * sc, 0.17, 0.51, 0.12), (-120.0 * sc, 0.52, 0.93, 0.12)]
        if kick:
            segs.append((kick, 0.86, 0.95, 0.04))
        return "scurve", W.BendSegments(segs)
    return "wounded", W.BendSegments([(p["bend"], 0.30, 0.66, 0.10), (p["kick"], 0.83, 0.94, 0.04)])


def job(a):
    kind, p = a
    design, bend = variant(kind, p)
    body = fish3.make_body(design, {"HEAD": p["g"] / (HEAD_CC * 10)}, bend=bend)
    fr = fish3.run(body)
    m = fish3.metrics(fr, body)
    ok, ch = fish3.target_score(m)
    return kind, p, m, ok, ch


if __name__ == "__main__":
    J = [("S", dict(scale=s, g=g)) for s in (0.6, 0.8, 1.0) for g in (15, 25)]
    J += [("S", dict(scale=0.8, g=20, kick=25)), ("S", dict(scale=0.6, g=20, kick=25))]
    J += [("W", dict(bend=b, kick=k, g=g)) for b in (0, 30) for k in (20, 40) for g in (12, 20)]
    with Pool(2) as pool:
        for kind, p, m, ok, ch in pool.imap_unordered(job, J):
            print(kind, p, "OK" if ok else "--", {k: v for k, v in ch.items() if not v},
                  {k: m[k] for k in ("net_g", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    print("EXPLORE_DONE")
