"""
Body-following cavities for the head-down variant.

Each cavity is the fish's own interior between x0 and x1, shrunk by WALL on every
side, optionally limited to a y band. Ballast cavities straddle the split plane
(open on each half's flat face, filled with tungsten putty before gluing).
Air cavities sit above / below a 4 mm web around the wire channel, so each is a
sealed void printed inside one half.
"""
import numpy as np
import triangle as tr
import trimesh
import manifold3d as m3d
import mackerel_geom as G

FL = G.FL
WALL = 1.8
ZMIN = 1.0           # minimum cavity half-thickness (mm)

# name, x0, x1 (fraction of FL), y band (mm, flat frame) or None, kind
SPECS = [
    ("HEAD", 0.050, 0.205, None, "ballast"),
    ("GUT", 0.215, 0.330, (-99.0, 1.0), "ballast"),
    ("FLOAT_BACK", 0.365, 0.700, (2.0, 99.0), "air"),
    ("FLOAT_BELLY", 0.365, 0.700, (-99.0, -2.0), "air"),
]


def zc(x, y):
    return G.body_z(np.atleast_1d(x), np.atleast_1d(y))[0] - WALL


def region(x0, x1, band):
    xs = np.linspace(x0 * FL, x1 * FL, 70)
    top, bot = [], []
    for x in xs:
        H, c = float(G.halfdepth_mm(x)), float(G.center_mm(x))
        ys = np.linspace(c - H + WALL, c + H - WALL, 600)
        if band:
            ys = ys[(ys >= band[0]) & (ys <= band[1])]
        ok = ys[zc(np.full_like(ys, x), ys) >= ZMIN]
        if len(ok) < 2:
            continue
        top.append((x, ok.max())); bot.append((x, ok.min()))
    return np.array(top + bot[::-1])


def cavity_mesh(name, x0, x1, band):
    ring = region(x0, x1, band)
    # drop near-duplicate points
    keep = [0]
    for i in range(1, len(ring)):
        if np.hypot(*(ring[i] - ring[keep[-1]])) > 0.05:
            keep.append(i)
    ring = ring[keep]
    n = len(ring)
    T = tr.triangulate(dict(vertices=ring, segments=np.c_[np.arange(n), (np.arange(n) + 1) % n]), "pq25a0.8")
    V2, F = T["vertices"], T["triangles"]
    p = V2[F]
    ar = (p[:, 1, 0] - p[:, 0, 0]) * (p[:, 2, 1] - p[:, 0, 1]) - (p[:, 2, 0] - p[:, 0, 0]) * (p[:, 1, 1] - p[:, 0, 1])
    F[ar < 0] = F[ar < 0][:, ::-1]
    z = np.maximum(zc(V2[:, 0], V2[:, 1]), ZMIN)
    nv = len(V2)
    V = np.r_[np.c_[V2, z], np.c_[V2, -z]]
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    key = {tuple(k) for k in e}
    b = np.array([k for k in e if (k[1], k[0]) not in key])
    Fa = np.vstack([F, F[:, ::-1] + nv, np.c_[b[:, 1], b[:, 0], b[:, 0] + nv], np.c_[b[:, 1], b[:, 0] + nv, b[:, 1] + nv]])
    return V, Fa


def cavities():
    out = []
    for name, x0, x1, band, kind in SPECS:
        V, F = cavity_mesh(name, x0, x1, band)
        tm = trimesh.Trimesh(V, F, process=False)
        assert tm.is_watertight, name
        out.append(dict(name=name, kind=kind, V=V, F=F, cc=round(tm.volume / 1000, 3),
                        centre=tm.center_mass.round(2).tolist(), x0=x0, x1=x1, band=band))
    return out


def manifold_of(c):
    M = m3d.Manifold(m3d.Mesh(vert_properties=c["V"].astype(np.float32), tri_verts=c["F"].astype(np.uint32)))
    assert M.status() == m3d.Error.NoError, c["name"]
    return M


if __name__ == "__main__":
    for c in cavities():
        print(c["name"], c["kind"], c["cc"], "cc", "centre", c["centre"])
