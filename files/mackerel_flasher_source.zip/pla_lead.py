"""One-piece solid PLA head-down body with a lead slug in an eye-to-eye bore."""
import json, sys
from multiprocessing import Pool
import fish3, wounded as W, mackerel_geom as G

EYE = (G.EYE_X, G.EYE_Y, 0.0)


def body_for(p, rho=1220.0, coat=0.0, coef=None, lead_dx=0.0):
    bend = W.BendSegments([(p["bend"], 0.30, 0.66, 0.10), (p["kick"], 0.83, 0.94, 0.04)]) if (p["bend"] or p["kick"]) else None
    extra = [(p["lead"], (EYE[0] + lead_dx, EYE[1], 0.0), p["lead"] / 11.34)] if p["lead"] else None
    return fish3.make_uniform_body(bend, rho_p=rho, coat_g=coat, coef=coef, extra=extra)


def job(p):
    b = body_for(p)
    fr = fish3.run(b)
    m = fish3.metrics(fr, b)
    ok, ch = fish3.target_score(m)
    return p, m, ok, ch


if __name__ == "__main__":
    J = [dict(bend=b, kick=k, lead=l) for b in (20, 30, 40) for k in (0, 15, 30) for l in (4, 7, 10)]
    with Pool(2) as pool:
        for p, m, ok, ch in pool.imap_unordered(job, J):
            print(p, "OK" if ok else "--", [k for k, v in ch.items() if not v],
                  {k: m[k] for k in ("net_g", "sink", "head_down", "head_down_osc", "roll_osc", "yaw_rate", "sway_m")}, flush=True)
    print("LEAD_DONE")
