"""Finished-look preview + developed (unrolled) waterslide decals at 1:1 scale."""
import numpy as np
from matplotlib.path import Path
from PIL import Image
import mackerel_geom as G
import pattern as PT

FL = G.FL
OUT = "out"
POLY = G.outline()
PATH = Path(np.asarray(POLY.exterior.coords))
X0, X1 = POLY.bounds[0] - 1, POLY.bounds[2] + 1
Y0, Y1 = POLY.bounds[1] - 1, POLY.bounds[3] + 1


def inside(x, y):
    return PATH.contains_points(np.c_[x.ravel(), y.ravel()]).reshape(x.shape)


def classify(x, y):
    ins = inside(x, y)
    zb, t = G.body_z(x.ravel(), y.ravel())
    zb, t = zb.reshape(x.shape), t.reshape(x.shape)
    is_fin = ins & ((np.abs(t) >= 1) | (x > G.BODY_END_U * FL) | (zb < 0.05))
    return ins, t, is_fin


# --------------------------------------------------------------------------- preview
def preview(res=0.12):
    xs = np.arange(X0, X1, res)
    ys = np.arange(Y1, Y0, -res)
    x, y = np.meshgrid(xs, ys)
    ins, t, is_fin = classify(x, y)
    z = np.where(ins, G.surface_z(x.ravel(), y.ravel()).reshape(x.shape), 0)
    dzdy, dzdx = np.gradient(z, -res, res)
    n = np.dstack([-dzdx, -dzdy, np.ones_like(z)])
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    # underwater "chrome": bright from the sky side, darker below, sharp highlight
    up = n[..., 1]
    env = 0.30 + 0.55 * ((up + 1) / 2) ** 1.6
    L = np.array([-0.35, 0.55, 0.76]); L /= np.linalg.norm(L)
    h = L + np.array([0, 0, 1.0]); h /= np.linalg.norm(h)
    spec = np.clip(n @ h, 0, 1) ** 60
    diff = np.clip(n @ L, 0, 1)
    chrome = (env * (0.75 + 0.25 * diff))[..., None] * PT.hexc("#d9e2e8") + spec[..., None] * 0.9
    rgb, a = PT.colour(x, y, t, is_fin)
    filt = (1 - a[..., None]) + a[..., None] * np.clip(rgb * 1.35, 0, 1)
    img = np.clip(chrome * filt + spec[..., None] * 0.25, 0, 1)
    # stick-on 3D eye
    d = np.hypot(x - G.EYE_X, y - G.EYE_Y)
    r = G.EYE_D / 2
    eye = d < r
    iris = np.dstack([np.full(x.shape, 0.80), np.full(x.shape, 0.74), np.full(x.shape, 0.52)])
    pupil = d < r * 0.55
    ecol = np.where(pupil[..., None], 0.04, iris * (0.75 + 0.25 * np.clip((y - G.EYE_Y) / r, -1, 1)[..., None]))
    hl = np.exp(-((x - G.EYE_X + r * 0.3) ** 2 + (y - G.EYE_Y - r * 0.35) ** 2) / (r * 0.18) ** 2)
    ecol = np.clip(ecol + hl[..., None] * 0.9, 0, 1)
    img = np.where(eye[..., None], ecol, img)
    bg = np.ones_like(img) * PT.hexc("#0f3b57")
    grad = np.linspace(1.15, 0.65, img.shape[0])[:, None, None]
    bg = np.clip(bg * grad, 0, 1)
    img = np.where(ins[..., None], img, bg)
    Image.fromarray((img * 255).astype(np.uint8)).save(f"{OUT}/preview_finished_left_flank.png")
    return img


# --------------------------------------------------------------------------- decal
def developed_decal(dpi=600):
    px = 25.4 / dpi
    xs = np.arange(X0, X1, px)
    yfine = np.arange(Y0 - 2, Y1 + 2, 0.02)
    # arc length along y for every column, measured from the body centre line
    S_all = []
    for i in range(0, len(xs), 400):
        xc = xs[i:i + 400]
        X, Yf = np.meshgrid(xc, yfine, indexing="ij")
        Z = G.surface_z(X.ravel(), Yf.ravel(), details=False).reshape(X.shape)
        ins = inside(X, Yf)
        Z = np.where(ins, Z, G.FIN_T)
        ds = np.sqrt(0.02 ** 2 + np.diff(Z, axis=1) ** 2)
        S = np.c_[np.zeros(len(xc)), np.cumsum(ds, axis=1)]
        yc = G.center_mm(xc)
        S0 = np.array([np.interp(yc[k], yfine, S[k]) for k in range(len(xc))])
        S_all.append(S - S0[:, None])
    S_all = np.vstack(S_all)
    smin, smax = None, None
    # extents of the developed outline
    ins_full = []
    tops, bots = [], []
    for i in range(0, len(xs), 400):
        X, Yf = np.meshgrid(xs[i:i + 400], yfine, indexing="ij")
        m = inside(X, Yf)
        for k in range(m.shape[0]):
            idx = np.nonzero(m[k])[0]
            if len(idx):
                tops.append(S_all[i + k, idx[-1]]); bots.append(S_all[i + k, idx[0]])
    smax, smin = max(tops) + 1, min(bots) - 1
    Ss = np.arange(smax, smin, -px)
    H, W = len(Ss), len(xs)
    out = np.ones((H, W, 3))
    mask = np.zeros((H, W), bool)
    for i in range(0, W, 300):
        xc = xs[i:i + 300]
        # invert S -> y per column
        Y = np.stack([np.interp(Ss, S_all[i + k], yfine) for k in range(len(xc))], axis=1)
        X = np.broadcast_to(xc[None, :], Y.shape).copy()
        ins, t, is_fin = classify(X, Y)
        rgb, a = PT.colour(X, Y, t, is_fin)
        a = np.where(ins, a, 0)
        out[:, i:i + 300] = a[..., None] * rgb + (1 - a[..., None])
        mask[:, i:i + 300] = ins
    # thin grey cut line around the decal
    from scipy.ndimage import binary_dilation
    ring = binary_dilation(mask, iterations=3) & ~mask
    out[ring] = 0.55
    img = Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8))
    img.save(f"{OUT}/decal_LEFT_flank_600dpi.png", dpi=(dpi, dpi))
    img.transpose(Image.FLIP_LEFT_RIGHT).save(f"{OUT}/decal_RIGHT_flank_600dpi.png", dpi=(dpi, dpi))
    size_mm = (W * px, H * px)
    proj_h = POLY.bounds[3] - POLY.bounds[1]
    return size_mm, proj_h


if __name__ == "__main__":
    preview()
    size, ph = developed_decal()
    print("decal size mm:", [round(v, 1) for v in size], "projected height:", round(ph, 1))
