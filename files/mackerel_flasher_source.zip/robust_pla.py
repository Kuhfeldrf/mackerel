"""Robustness test for solid single-material (PLA) designs."""
import json, sys
from multiprocessing import Pool
import numpy as np
import fish3, sim3
from robust3 import RANGES
from pla_explore import shape

K = 12


def samples(k=K, seed=23):
    rng = np.random.default_rng(seed)
    strata = {n: rng.permutation(k) for n in RANGES}
    out = []
    for i in range(k):
        coef = {n: lo + (hi - lo) * (strata[n][i] + rng.random()) / k for n, (lo, hi) in RANGES.items()}
        axis = rng.normal(size=3); axis /= np.linalg.norm(axis)
        out.append(dict(coef=coef, rho=float(rng.uniform(1180, 1250)), coat=float(rng.uniform(0, 5)),
                        wire=0.0, toss_axis=axis.tolist(), toss_deg=float(rng.uniform(0, 70)),
                        v_scale=float(rng.uniform(0.5, 1.5))))
    return out


def one(a):
    kind, p, smp = a
    body = fish3.make_uniform_body(shape(kind, p), rho_p=smp["rho"], coat_g=smp["coat"], wire_g=smp["wire"], coef=smp["coef"])
    R0 = sim3.rot(smp["toss_axis"], smp["toss_deg"]) @ fish3.R_START
    try:
        fr = fish3.run(body, R0=R0, v0=np.array([0.7, -0.25, 0.15]) * smp["v_scale"])
    except RuntimeError:
        return None
    m = fish3.metrics(fr, body)
    ok, ch = fish3.target_score(m)
    return dict(m=m, ok=ok, checks=ch)


if __name__ == "__main__":
    cands = json.loads(sys.argv[1])
    S = samples()
    jobs = [(c[0], c[1], s) for c in cands for s in S]
    with Pool(2) as pool:
        res = pool.map(one, jobs)
    out = []
    for i, (kind, p) in enumerate(cands):
        rs = [r for r in res[i * K:(i + 1) * K] if r]
        q = lambda f: np.percentile([f(r["m"]) for r in rs], [10, 50, 90]).round(2).tolist()
        out.append(dict(kind=kind, p=p, success=f"{sum(r['ok'] for r in rs)}/{len(rs)}",
                        each={c: sum(r["checks"][c] for r in rs) for c in rs[0]["checks"]},
                        sink=q(lambda m: m["sink"]), head_down=q(lambda m: m["head_down"]),
                        rock=q(lambda m: 1.4 * max(m["roll_osc"], m["head_down_osc"])),
                        turn_s=q(lambda m: 360 / max(abs(m["yaw_rate"]), 1)), sway=q(lambda m: m["sway_m"]),
                        net_g=q(lambda m: m["net_g"])))
        print(json.dumps(out[-1]), flush=True)
    json.dump(out, open(sys.argv[2], "w"), indent=1)
    print("ROBUST_DONE")
