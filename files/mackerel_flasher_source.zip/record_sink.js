// Records the viewer's sink test to PNG frames, frame-by-frame (deterministic).
// usage: node record_sink.js <page.html> <outdir> <design> <fills comma> [fps] [w] [h] [mode]
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const SCR = '/tmp/claude-0/-home-claude/67ba0dbe-879c-5d6c-9294-40ec9c00cdfe/scratchpad/';
const P = SCR + 'npm/package/';
const FONTS = SCR + 'npm/fonts/';
const [page, outdir, design, fillsArg, fpsArg, wArg, hArg, mode] = process.argv.slice(2);
const fps = +(fpsArg || 30), W = +(wArg || 1280), H = +(hArg || 720);
let fills = fillsArg ? fillsArg.split(',').filter(Boolean) : [];
if (design === 'wounded') { const o = { HEAD: 0, GUT: false }; fills.forEach(k => { if (k.startsWith('HEAD@')) o.HEAD = +k.slice(5); else o[k] = true; }); fills = o; }
const woff = f => 'data:font/woff2;base64,' + fs.readFileSync(f).toString('base64');
const fontCss = `
@font-face{font-family:"Archivo";font-style:normal;font-display:block;font-weight:100 900;font-stretch:62% 125%;
 src:url(${woff(FONTS + 'fontsource-variable-archivo-5.0.20/package/files/archivo-latin-wdth-normal.woff2')}) format("woff2-variations");}
@font-face{font-family:"IBM Plex Mono";font-style:normal;font-weight:400;font-display:block;src:url(${woff(FONTS + 'fontsource-ibm-plex-mono-5.0.13/package/files/ibm-plex-mono-latin-400-normal.woff2')}) format("woff2");}
@font-face{font-family:"IBM Plex Mono";font-style:normal;font-weight:500;font-display:block;src:url(${woff(FONTS + 'fontsource-ibm-plex-mono-5.0.13/package/files/ibm-plex-mono-latin-500-normal.woff2')}) format("woff2");}
@font-face{font-family:"IBM Plex Mono";font-style:italic;font-weight:400;font-display:block;src:url(${woff(FONTS + 'fontsource-ibm-plex-mono-5.0.13/package/files/ibm-plex-mono-latin-400-italic.woff2')}) format("woff2");}`;
(async () => {
  fs.mkdirSync(outdir, { recursive: true });
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const pg = await b.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
  const logs = [];
  pg.on('pageerror', e => logs.push('PAGEERROR ' + e.message));
  pg.on('console', m => { if (m.type() === 'error') logs.push(m.text()); });
  await pg.route('**/three.min.js', r => r.fulfill({ body: fs.readFileSync(P + 'build/three.min.js'), contentType: 'application/javascript' }));
  await pg.route('**/OrbitControls.js', r => r.fulfill({ body: fs.readFileSync(P + 'examples/js/controls/OrbitControls.js'), contentType: 'application/javascript' }));
  await pg.route('https://fonts.googleapis.com/**', r => r.fulfill({ body: fontCss, contentType: 'text/css' }));
  await pg.route('https://fonts.gstatic.com/**', r => r.abort());
  const html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}[hidden]{display:none!important}</style></head><body>' + fs.readFileSync(page, 'utf8') + '</body></html>';
  const tmp = SCR + 'rec_page.html';
  fs.writeFileSync(tmp, html);
  await pg.goto('file://' + tmp);
  await pg.evaluate(() => document.fonts.ready);
  await pg.waitForTimeout(2500);
  if (mode === 'shots') {
    // UI screenshots for checking
    await pg.screenshot({ path: path.join(outdir, 'ui_default.png') });
    await pg.click('#simPlay'); await pg.waitForTimeout(6000);
    await pg.screenshot({ path: path.join(outdir, 'ui_sim.png') });
    console.log(logs.join('\n')); await b.close(); return;
  }
  await pg.evaluate(() => document.body.classList.add('record'));
  await pg.waitForTimeout(600);
  const dur = await pg.evaluate(([d, f]) => window.__sink.start(d, f), [design, fills]);
  const hold = 1.5, total = Math.ceil((dur + hold) * fps);
  console.log('duration', dur, 'frames', total);
  const stage = await pg.$('#stage');
  const t0 = Date.now();
  for (let f = 0; f < total; f++) {
    const t = Math.min(f / fps, dur);
    await pg.evaluate(t => window.__sink.seek(t), t);
    await stage.screenshot({ path: path.join(outdir, 'f' + String(f).padStart(5, '0') + '.png') });
    if (f % 100 === 0) console.log('frame', f, ((Date.now() - t0) / 1000).toFixed(0) + 's');
  }
  console.log(logs.join('\n'));
  await b.close();
})();
